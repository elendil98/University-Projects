package frames;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import classes.Hall;

public class FrameHallView extends JFrame{

	private static final long serialVersionUID = 1L;

	private JPanel hallViewPanel;
	
	public FrameHallView(Hall hall) {
		
		hallViewPanel = new JPanel();
		hallViewPanel.setLayout(new GridLayout(2,1));
		
		JPanel screenPanel = createScreenPanel();
		JPanel seatsPanel = createSeatsPanel(hall);
		seatsPanel.setLayout(new BoxLayout(seatsPanel, BoxLayout.Y_AXIS));
		
		hallViewPanel.add(screenPanel);
		hallViewPanel.add(seatsPanel);
		
		setTitle("Visualizzazione Sala");
		setSize(600, 700);
		setResizable(false);
		setVisible(true);
		add(hallViewPanel);
	}
	
	private JPanel createScreenPanel() {
		
		JPanel panel = new JPanel();
		
		JTextArea screenArea = new JTextArea(15, 35);
		screenArea.setEditable(false);
		
		panel.add(screenArea);
		
		return panel;
		
	}
	
	private JPanel createSeatsPanel(Hall hall) {
		
		JPanel mainPanel = new JPanel();
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(12, 10, 1,1));
		
		for(int i = 0; i < hall.getSeatNumber(); i++) {
			
			JButton button = new JButton("" + (i + 1));
			button.setFont(new Font("Arial", Font.BOLD, 10));
			panel.add(button);
			button.setEnabled(false);
			
		}
		
		JPanel backPanel = createBackPanel();
		
		mainPanel.setLayout(new GridLayout(2, 1));
		mainPanel.add(panel);
		mainPanel.add(backPanel);
		
		return mainPanel;
		
	}
	
	private JPanel createBackPanel() {
		
		class BackButtonListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {

				setAlwaysOnTop(false);
				setVisible(false);
				dispose();
				
			}
			
		}
		
		JPanel panel = new JPanel();
	
		JButton backButton = new JButton("Indietro");
		backButton.addActionListener(new BackButtonListener());

		panel.add(backButton);
		
		return panel;
		
	}

}
