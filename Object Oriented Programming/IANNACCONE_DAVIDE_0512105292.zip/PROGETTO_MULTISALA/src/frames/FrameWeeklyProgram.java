package frames;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import classes.FileManager;
import classes.Film;
import classes.Hall;
import classes.Multiplex;

public class FrameWeeklyProgram extends JFrame{

	private static final long serialVersionUID = 1L;

	private static final DateFormat sdfDate = new SimpleDateFormat("yyyy/MM/dd");
	private Date date;
	
	
	private JPanel mainPanel;
	private JPanel panel1;
	private JPanel panel2;
	private JPanel panel3;
	private JPanel panel4;
	private JPanel panel5;
	private JPanel panel6;
	private JPanel panel7End;
	private JTextArea areaOutput;
	private String[] timeString = {"12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", 
			"17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30"};
	
	private String localDate;
	private String[] filmList;
	private Hall hall;
	private Multiplex multiplex;
	
	public FrameWeeklyProgram(Multiplex multiplex, Hall hall) {
		
		this.hall = hall;
		this.multiplex = multiplex;
		
		date = new Date();
		
		mainPanel = new JPanel();
		areaOutput = new JTextArea(10, 10);
		areaOutput.setEditable(false);
		JScrollPane areaPane = new JScrollPane(areaOutput);
		
		localDate = sdfDate.format(date);
		
		filmList = new String[multiplex.getFilmList().size()];
		
		for(int i = 0; i < multiplex.getFilmList().size(); i++) {
			
			filmList[i] = multiplex.getFilmList().get(i).getName();
			
		}
		
		String changedLocalDate = localDate.substring(0, 8);
		int dayNumber = Integer.parseInt(localDate.substring(8));
		
		panel1 = createPanel(changedLocalDate + dayNumber);
		panel2 = createPanel(changedLocalDate + (dayNumber + 1));
		panel3 = createPanel(changedLocalDate + (dayNumber + 2));
		panel4 = createPanel(changedLocalDate + (dayNumber + 3));
		panel5 = createPanel(changedLocalDate + (dayNumber + 4));
		panel6 = createPanel(changedLocalDate + (dayNumber + 5));
		panel7End = createBackPanel();
		
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
	
		mainPanel.add(panel1);
		mainPanel.add(panel2);
		mainPanel.add(panel3);
		mainPanel.add(panel4);
		mainPanel.add(panel5);
		mainPanel.add(panel6);
		mainPanel.add(panel7End);
		mainPanel.add(areaPane);
		
		setTitle("Programma Settimanale");
		setSize(525, 700);
		setResizable(false);
		setVisible(true);
		add(mainPanel);
		
	}
	
	public JPanel createBackPanel() {
		
		class ViewAllShowListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(hall.getShowArray().size() == 0) {
					areaOutput.append("Non ci sono ancora spettacoli");
				}
				else {
					
					for(int i = 0; i < hall.getShowArray().size(); i++) {
						
						areaOutput.append(hall.getShowArray().get(i).toString());
						
					}
					
				}
				
			}
			
		}
		
		class BackButtonListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				setAlwaysOnTop(false);
				setVisible(false);
				dispose();
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		JButton backButton = new JButton("Indietro");
		backButton.addActionListener(new BackButtonListener());
		
		JButton viewButton = new JButton("Visualizza Spettacoli");
		viewButton.addActionListener(new ViewAllShowListener());
		
		panel.add(backButton);
		panel.add(viewButton);
		
		return panel;
		
	}
	
	public JPanel createPanel(String localDate) {
		
		JComboBox<String> filmBox = createComboBox(filmList);
		JComboBox<String> timeBox = createComboBox(timeString);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(), "Giorno: " + localDate));
		panel.setLayout(new GridLayout(2, 3));
		
		JLabel labelFilmName = new JLabel("Scegli Film");
		JLabel labelTime = new JLabel("Scegli Ora Inizio");
		
		JButton buttonAdd = new JButton("Aggiungi");
		ActionListener listener = new AddShowListener(filmBox, timeBox, localDate);
		buttonAdd.addActionListener(listener);
		
		panel.add(labelFilmName);
		panel.add(filmBox);
		panel.add(buttonAdd);
		panel.add(labelTime);
		panel.add(timeBox);
		
		return panel;
		
	}
	
	private JComboBox<String> createComboBox(String[] stringList) {
		
		JComboBox<String> comboBox = new JComboBox<String>(stringList);
		
		return comboBox;
		
	}
	
	public class AddShowListener implements ActionListener {
		
		JComboBox<String> filmBox;
		JComboBox<String> timeBox;
		String date;
		
		public AddShowListener(JComboBox<String> filmBox, JComboBox<String> timeBox, String date) {
		
			this.filmBox = filmBox;
			this.timeBox = timeBox;
			this.date = date;
			
		}
		
		public void actionPerformed(ActionEvent event) {
			
			if(filmBox.getSelectedItem() != null) {
				
				Film film = multiplex.getFilmName(filmBox.getSelectedItem().toString());
				if(hall.addShow(film, date, timeBox.getSelectedItem().toString())) {
					
					areaOutput.append("Aggiunto: " + film.getName() + ", in Data: " + date + " alle Ore: " + timeBox.getSelectedItem().toString() + "\n");
					
				}
				
				FileManager.saveFile(multiplex);
				
			}
			
		}
	}
	
}
