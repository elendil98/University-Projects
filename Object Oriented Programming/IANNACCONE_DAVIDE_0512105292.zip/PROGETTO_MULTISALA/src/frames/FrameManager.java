package frames;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTable;

import classes.Account;
import classes.Manager;
import classes.Multiplex;
import menus.AccountMenu;
import menus.FilmMenu;
import menus.HallMenu;
import menus.MultiplexMenu;
import menus.PoliticMenu;

public class FrameManager extends JFrame {
	
	private static final long serialVersionUID = 1L;

	private JPanel mainPanel;
	private JPanel labelPanel;
	JPanel changeCredentialsPanel;
	JPanel changeMultiplexPanel;
	private JLabel labelWelcomeName;
	private JLabel labelWelcomeSurname;
	private JMenuBar menuBar;
	private JMenu menuManagerActions;
	private JMenu menuMultiplex;
	private JMenu menuFilm;
	private JMenu menuHall;
	private JMenu menuPolitic;
	JTable clientTable;
	JButton changeUsernameButton;
	JButton changePasswordButton;
	private Manager manager;
	private Multiplex multiplex;
	private JFrame frameChoice;
	
	public FrameManager(Account manager, Multiplex multiplex, FrameChoice frameChoice) {
		
		this.frameChoice = frameChoice;
		this.manager = (Manager) manager;
		this.multiplex = multiplex;
		
		mainPanel = new JPanel();
		labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(3, 1));
		
		labelPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		labelWelcomeName = new JLabel("Benvenuto " + this.manager.getName() + " qui pu� gestire il multisala " + multiplex.getName());
		labelWelcomeName.setForeground(new Color(0.8F, 0.8F, 0.8F));
		labelWelcomeSurname = new JLabel("                    Utilizzare il menu soprastante");
		labelWelcomeSurname.setForeground(new Color(0.8F, 0.8F, 0.8F));
		
		labelPanel.add(labelWelcomeName);
		labelPanel.add(new JLabel(""));
		labelPanel.add(labelWelcomeSurname);
		
		mainPanel.setLayout(new GridBagLayout());
		mainPanel.add(labelPanel);
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		mainPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		menuBar = createMenuBar();
		setJMenuBar(menuBar);
		
		add(mainPanel);
		
		setSize(800, 500);
		setResizable(false);
		setTitle("Gestione Multisala " + multiplex.getName());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
			
	}
	
	public JMenuBar createMenuBar() {
	
		JMenuBar bar = new JMenuBar();
		
		menuManagerActions = new AccountMenu(multiplex, mainPanel, manager, frameChoice, this);
		menuMultiplex = new MultiplexMenu(multiplex, mainPanel);
		menuHall = new HallMenu(multiplex, mainPanel);
		menuFilm = new FilmMenu(multiplex, mainPanel);
		menuPolitic = new PoliticMenu(multiplex, mainPanel);
		
		bar.add(menuManagerActions);
		bar.add(menuMultiplex);
		bar.add(menuHall);
		bar.add(menuFilm);
		bar.add(menuPolitic);
		
		return bar;
		
	}
	
}
