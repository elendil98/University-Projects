package frames;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;

import classes.Account;
import classes.Client;
import classes.Multiplex;
import menus.ClientMenu;
import menus.WeeklyProgramMenu;

public class FrameClient extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	private JMenuBar menuBar;
	private JMenu menuWeeklyProgram;
	private JMenu menuClientActions;
	private JLabel labelWelcomeSurname;
	private JLabel labelWelcomeName;
	private JPanel labelPanel;
	private JPanel mainPanel;
	private JFrame frameChoice;
	private Multiplex multiplex;
	private Client client;
	
	public FrameClient(Account client, Multiplex multiplex, JFrame frameChoice) {
		
		this.frameChoice = frameChoice;
		this.client = (Client) client;
		this.multiplex = multiplex;
		
		mainPanel = new JPanel();
		labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(3, 1));
		
		labelPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		labelWelcomeName = new JLabel("Benvenuto " + this.client.getName() + " qui pu� usufruire del multisala " + multiplex.getName());
		labelWelcomeName.setForeground(new Color(0.8F, 0.8F, 0.8F));
		labelWelcomeSurname = new JLabel("                    Utilizzare il menu soprastante");
		labelWelcomeSurname.setForeground(new Color(0.8F, 0.8F, 0.8F));
		
		labelPanel.add(labelWelcomeName);
		labelPanel.add(new JLabel(""));
		labelPanel.add(labelWelcomeSurname);
		
		mainPanel.setLayout(new GridBagLayout());
		mainPanel.add(labelPanel);
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		mainPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		menuBar = createMenuBar();
		setJMenuBar(menuBar);
		
		add(mainPanel);
		
		setSize(800, 500);
		setResizable(false);
		setTitle("Benvenuto nel Multisala " + multiplex.getName());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	public JMenuBar createMenuBar() {
		
		JMenuBar bar = new JMenuBar();
		
		menuClientActions = new ClientMenu(multiplex, mainPanel, client, frameChoice, this);
		menuWeeklyProgram = new WeeklyProgramMenu(multiplex, mainPanel, client);
		
		bar.add(menuClientActions);
		bar.add(menuWeeklyProgram);
		
		return bar;
		
	}

}
