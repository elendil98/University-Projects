package frames;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import classes.Account;
import classes.Multiplex;

public class FrameChoice extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	JButton buttonLogin;
	JPanel panelLogin;
	JPanel panelButtonCreate;
	JPanel panelAccountCredentials;
	JTextField fieldUsername;
	JTextField fieldPassword;
	JLabel labelUsername;
	JLabel labelPassword;
	JButton buttonCreateAccount;
	
	public FrameChoice(Multiplex multiplex) {
		
		panelAccountCredentials = new JPanel();
		panelLogin = createLoginPanel(multiplex);
		panelButtonCreate = createButtonCreatePanel(multiplex);
		
		labelUsername = new JLabel("Inserisci Username");
		labelPassword = new JLabel("Inserisci Password");
		labelUsername.setForeground(new Color(0.8F, 0.8F, 0.8F));
		labelPassword.setForeground(new Color(0.8F, 0.8F, 0.8F));
		
		fieldUsername = new JTextField(2);
		fieldPassword = new JTextField(2);
			
		panelAccountCredentials.setBackground(new Color(0.3F, 0.3F, 0.3F));
		panelAccountCredentials.setLayout(new GridLayout(4, 2));
		
		panelAccountCredentials.add(labelUsername);
		panelAccountCredentials.add(fieldUsername);
		
		JPanel voidPanel = new JPanel();
		voidPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		JPanel voidPanel2 = new JPanel();
		voidPanel2.setBackground(new Color(0.3F, 0.3F, 0.3F));
		JPanel voidPanel3 = new JPanel();
		voidPanel3.setBackground(new Color(0.3F, 0.3F, 0.3F));
		JPanel voidPanel4 = new JPanel();
		voidPanel4.setBackground(new Color(0.3F, 0.3F, 0.3F));

		panelAccountCredentials.add(voidPanel);
		panelAccountCredentials.add(voidPanel2);
		
		panelAccountCredentials.add(labelPassword);
		panelAccountCredentials.add(fieldPassword);
		
		panelAccountCredentials.add(voidPanel3);
		panelAccountCredentials.add(voidPanel4);
		
		setLayout(new GridLayout(3, 1));
		add(panelAccountCredentials);
		add(panelButtonCreate);
		add(panelLogin);
		
		pack();
		setTitle("Accesso");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	public JPanel createButtonCreatePanel(Multiplex multiplex) {
		
		class CreateAccountListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				JFrame frameCreateAccount = new FrameCreateAccount(FrameChoice.this, multiplex);
				frameCreateAccount.setVisible(true);
				setVisible(false);
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		buttonCreateAccount = new JButton("Crea Account");
		buttonCreateAccount.addActionListener(new CreateAccountListener());
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		panel.add(buttonCreateAccount);	
		
		return panel;
		
	}
	
	public JPanel createLoginPanel(Multiplex multiplex) {
		
		class SetChoiceListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
			
				if(multiplex.getAccountList().size() > 0 ) {
					
					Account account = multiplex.searchAccount(fieldUsername.getText(), fieldPassword.getText());
					
					if(account == null) {
								
						JOptionPane.showMessageDialog(panelAccountCredentials, "Username o Password non trovati", "Errore", JOptionPane.ERROR_MESSAGE);
								
					}
					else {
								
						if(account.getAccoutType()) {
								
							JFrame frameManager = new FrameManager(account, multiplex, FrameChoice.this);
							frameManager.setVisible(true);
							setVisible(false);
								
						}
						else {
							
							JFrame frameClient = new FrameClient(account, multiplex, FrameChoice.this);
							frameClient.setVisible(true);
							setVisible(false);
											
						}	
				
					}	
				
				}
				else {
					
					JOptionPane.showMessageDialog(panelAccountCredentials, "Nessun Account creato.", "Errore", JOptionPane.ERROR_MESSAGE);
					
				}
						
			}
			
		}
		
		JPanel panel = new JPanel();
		
		buttonLogin = new JButton("Login");
		buttonLogin.setBackground(new Color(0.5F, 0.5F, 1.0F));
		
		ActionListener listener = new SetChoiceListener();
		buttonLogin.addActionListener(listener);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		panel.add(buttonLogin);
		
		return panel;
		
	}
	
}
