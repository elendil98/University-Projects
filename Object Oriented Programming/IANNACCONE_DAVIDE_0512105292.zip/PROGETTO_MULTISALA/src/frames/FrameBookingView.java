package frames;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import classes.Client;
import classes.FileManager;
import classes.Multiplex;
import exception.PostoIndisponibileException;

public class FrameBookingView extends JFrame{

	private static final long serialVersionUID = 1L;

	private JPanel showViewPanel;
	private Client client;
	
	public FrameBookingView(Multiplex multiplex, int hallIndex, int showIndex, Client client) {
		
		this.client = client;
		showViewPanel = new JPanel();
		showViewPanel.setLayout(new GridLayout(2,1));
		
		JPanel screenPanel = createScreenPanel();
		JPanel seatsPanel = createSeatsPanel(multiplex, hallIndex, showIndex);
		seatsPanel.setLayout(new BoxLayout(seatsPanel, BoxLayout.Y_AXIS));
		
		showViewPanel.add(screenPanel);
		showViewPanel.add(seatsPanel);
		
		setTitle("Visualizzazione Sala");
		setSize(600, 700);
		setResizable(false);
		setVisible(true);
		add(showViewPanel);
			
	}

	private JPanel createScreenPanel() {
		
		JPanel panel = new JPanel();
		
		JTextArea screenArea = new JTextArea(15, 35);
		screenArea.setEditable(false);
		screenArea.setBackground(Color.BLACK);
		
		panel.add(screenArea);
		
		return panel;
		
	}

	private JPanel createSeatsPanel(Multiplex multiplex, int hallIndex, int showIndex) {
		
		class BookingListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				int number = (Integer.parseInt(event.getActionCommand()) - 1);
				if(multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().get(number).getType() == classes.Seat.Type.OCCUPATO) {
					JOptionPane.showMessageDialog(null, "Eccezione lanciata", "Eccezione", JOptionPane.INFORMATION_MESSAGE);
					try {
						throw new PostoIndisponibileException();
					} catch (PostoIndisponibileException e) {
						e.printStackTrace();
					}
				}
				else {
					
					if(multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().get(number).getType() == classes.Seat.Type.PRENOTATO) {
						JOptionPane.showMessageDialog(null, "Eccezione lanciata", "Eccezione", JOptionPane.INFORMATION_MESSAGE);
						try {
							throw new PostoIndisponibileException();
						} catch (PostoIndisponibileException e) {
							e.printStackTrace();
						}
					}
					else {
						
						multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().get(number).setType(classes.Seat.Type.PRENOTATO);
						client.addBookingSeat(multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().get(number));
						multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).setPrice(multiplex, client);
						JButton button = (JButton) event.getSource();
						button.setBackground(new Color(0.3F, 0.3F, 1.0F));
						
					}
					
				}
				
				FileManager.saveFile(multiplex);
				
			}
			
		}
		
		JPanel mainPanel = new JPanel();
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(12, 10, 1,1));
		
		for(int i = 0; i < multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().size(); i++) {
			
			JButton button = new JButton("" + (i + 1));
			
			if(multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().get(i).getType() == classes.Seat.Type.DISPONIBILE) {
				
				button.setFont(new Font("Arial", Font.BOLD, 10));
				button.setBackground(new Color(0.3F, 1.0F, 0.3F));
				
			}
			
			if(multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().get(i).getType() == classes.Seat.Type.PRENOTATO) {
				
				button.setFont(new Font("Arial", Font.BOLD, 10));
				button.setBackground(new Color(0.3F, 0.3F, 1.0F));
				
			}
			
			if(multiplex.getArrayHalls().get(hallIndex).getShowArray().get(showIndex).getSeatList().get(i).getType() == classes.Seat.Type.OCCUPATO) {
				
				button.setFont(new Font("Arial", Font.BOLD, 10));
				button.setBackground(new Color(1.0F, 0.3F, 0.3F));
				
			}
			
			button.addActionListener(new BookingListener());
			
			panel.add(button);
			
		}
		
		JPanel backPanel = createBackPanel();
		
		mainPanel.setLayout(new GridLayout(2, 1));
		mainPanel.add(panel);
		mainPanel.add(backPanel);
		
		return mainPanel;
		
	}
	

	private JPanel createBackPanel() {
		
		class BackButtonListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {

				setAlwaysOnTop(false);
				setVisible(false);
				dispose();
				
			}
			
		}
		
		JPanel panel = new JPanel();
	
		JButton backButton = new JButton("Indietro");
		backButton.addActionListener(new BackButtonListener());

		panel.add(backButton);
		
		return panel;
		
	}
	
}
