package frames;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import classes.BankAccount;
import classes.Client;
import classes.Manager;
import classes.Multiplex;

public class FrameCreateAccount extends JFrame {

	private static final long serialVersionUID = 1L;
	
	JPanel panelInput;
	JPanel panelButton;
	JButton buttonConfirm;
	JButton buttonBack;
	JLabel labelName;
	JLabel labelSurname;
	JLabel labelUsername;
	JLabel labelPassword;
	JLabel labelAge;
	JLabel labelBalance;
	JRadioButton radioClient;
	JRadioButton radioManager;
	JTextField fieldAge;
	JTextField fieldBalance;
	JTextField fieldUsername;
	JTextField fieldPassword;
	JTextField fieldName;
	JTextField fieldSurname;
	JFrame frameChoice;
	
	public FrameCreateAccount(JFrame frameChoice, Multiplex multiplex) {

		this.frameChoice = frameChoice;
		
		panelInput = createPanelInput();
		panelButton = createPanelButton(multiplex);
		
		setLayout(new GridLayout(2, 1));
		
		add(panelInput);
		add(panelButton);
		
		setSize(280, 280);
		setResizable(false);
		setTitle("Crea Account");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	public JPanel createPanelInput() {
		
		JPanel panel = new JPanel();
		
		labelUsername = new JLabel("Username:");
		labelPassword = new JLabel("Password:");
		labelName = new JLabel("Nome Manager:");
		labelSurname = new JLabel("Cognome Manager:");
		labelAge = new JLabel("Anni:");
		labelBalance = new JLabel("Bilancio Banca:");
		
		Color color = new Color(0.8F, 0.8F, 0.8F);
		
		labelName.setForeground(color);
		labelSurname.setForeground(color);
		labelUsername.setForeground(color);
		labelPassword.setForeground(color);
		labelAge.setForeground(color);
		labelBalance.setForeground(color);
		
		fieldName = new JTextField(5);
		fieldSurname = new JTextField(5);
		fieldUsername = new JTextField(5);
		fieldPassword = new JTextField(5);
		fieldAge = new JTextField(5);
		fieldBalance = new JTextField(5);
		
		labelAge.setVisible(false);
		labelBalance.setVisible(false);
		fieldAge.setVisible(false);
		fieldBalance.setVisible(false);
	
		panel.setLayout(new GridLayout(6, 1));
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		panel.add(labelUsername);
		panel.add(fieldUsername);
		panel.add(labelPassword);
		panel.add(fieldPassword);
		panel.add(labelName);
		panel.add(fieldName);
		panel.add(labelSurname);
		panel.add(fieldSurname);
		panel.add(labelAge);
		panel.add(fieldAge);
		panel.add(labelBalance);
		panel.add(fieldBalance);
				
		return panel;
		
	}
	
	public JPanel createPanelButton(Multiplex multiplex) {
		
		class backButtonListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				frameChoice.setVisible(true);
				dispose();
				
			}
			
		}
		
		class ConfirmButtonManagerListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(fieldUsername.getText().equals("") || fieldPassword.getText().equals("") || fieldName.getText().equals("") || fieldSurname.getText().equals("")) {
					
					JOptionPane.showMessageDialog(panelInput, "Riempire tutti i campi.", "Errore", JOptionPane.ERROR_MESSAGE);
					return;
					
				}
				else {
					
					if (multiplex.getAccountList() == null) {
						
						JOptionPane.showMessageDialog(panelInput, "Errore nella creazione del multisala.", "Errore", JOptionPane.ERROR_MESSAGE);
						return;
						
					}
					
					if(radioManager.isSelected()) {
					
						Manager manager = new Manager(fieldUsername.getText(), fieldPassword.getText(), fieldName.getText(), fieldSurname.getText());
						
						if(multiplex.addAccount(manager)) {
				
							frameChoice.setVisible(true);
							dispose();
							
						}
						else {
							
							JOptionPane.showMessageDialog(panelInput, "Utilizzare Username e/o password diversi", "Errore", JOptionPane.ERROR_MESSAGE);
							
						}
						
					}
					if(radioClient.isSelected()) {
						
						BankAccount bankAccount = new BankAccount(fieldName.getText(), Double.parseDouble(fieldBalance.getText()));
						Client client = new Client(fieldUsername.getText(), fieldPassword.getText(), fieldName.getText(), fieldSurname.getText(), Integer.parseInt(fieldAge.getText()), bankAccount);
		
						if(multiplex.addAccount(client)) {
							
							frameChoice.setVisible(true);
							dispose();
							
						}
						else {
							
							JOptionPane.showMessageDialog(panelInput, "Utilizzare Username e/o password diversi", "Errore", JOptionPane.ERROR_MESSAGE);
							
						}
						
					}
					
				}
			
			}
			
		}
		
		class radioButtonListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(radioManager.isSelected()) {
					
					labelAge.setVisible(false);
					labelBalance.setVisible(false);
					fieldAge.setVisible(false);
					fieldBalance.setVisible(false);
					labelName.setText("Nome Manager");
					labelSurname.setText("Cognome Manager");
					
				}
				if(radioClient.isSelected()) {
					
					labelAge.setVisible(true);
					labelBalance.setVisible(true);
					fieldAge.setVisible(true);
					fieldBalance.setVisible(true);
					labelName.setText("Nome Cliente");
					labelSurname.setText("Cognome Cliente");
					
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		JPanel panelButton = new JPanel();
		JPanel panelExtended = new JPanel();
		
		ActionListener listener = new ConfirmButtonManagerListener();
		
		radioManager = new JRadioButton("Manager");
		radioClient = new JRadioButton("Cliente");
		
		radioManager.setForeground(new Color(0.8F, 0.8F, 0.8F));
		radioClient.setForeground(new Color(0.8F, 0.8F, 0.8F));
		
		radioManager.setOpaque(false);
		radioClient.setOpaque(false);
		
		ButtonGroup group = new ButtonGroup();
		group.add(radioManager);
		group.add(radioClient);
		
		ActionListener listener2 = new radioButtonListener();
		radioManager.addActionListener(listener2);
		radioClient.addActionListener(listener2);
		
		radioManager.setSelected(true);
		
		buttonBack = new JButton("Indietro");
		buttonBack.addActionListener(new backButtonListener());
		
		buttonConfirm = new JButton("Crea Account");
		buttonConfirm.addActionListener(listener);
		
		
		panelExtended.add(radioManager);
		panelExtended.add(radioClient);
		
		panelButton.add(buttonBack);
		panelButton.add(buttonConfirm);
		
		Color color = new Color(0.3F, 0.3F, 0.3F);
		
		panelButton.setBackground(color);
		panel.setBackground(color);
		panelExtended.setBackground(color);
		
		panel.setLayout(new GridLayout(3, 1));
		
		panel.add(panelButton);
		panel.add(panelExtended);
		
		return panel;
		
	}
	
}
