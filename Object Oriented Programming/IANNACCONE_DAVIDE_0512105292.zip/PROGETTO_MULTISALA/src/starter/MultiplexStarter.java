package starter;

import javax.swing.JFrame;

import classes.FileManager;
import classes.Multiplex;
import frames.FrameChoice;

public class MultiplexStarter {

	public static void main(String args[]) {
		
		Multiplex multiplex = new Multiplex();
		multiplex = (Multiplex) FileManager.loadFile(multiplex);
		multiplex.refreshPoliticList();
		
		JFrame startFrame = new FrameChoice(multiplex);
		
		startFrame.setVisible(true);
		
	}
	
}
