package classes;

import java.io.Serializable;

public class BankAccount implements Cloneable, Serializable{

	private static final long serialVersionUID = 1L;

	private String name;
	private double balance;

	/**
	 * Create a new BankAccount
	 */

	public BankAccount(String name, double balance) {
		
		this.name = name;
		this.balance = balance;
	
	}
	
	/**	
	 * Insert a value to deposit in the BankAccount
	 * @param value
	 */
	
	public void deposit(double value) {
		
		balance += value;
	
	}
	
	/**
	 * Insert a value to withdraw from the BankAccount
	 * @param value 
	 */
	
	public void withdraw(double value) {
		
		balance -= value;
		
	}
	
	/**
	 * Return the Name of the BankAccount
	 * @return account name
	 */
	
	public String getName() {
		
		return name;
	
	}
	
	/**
	 * Return the Balance of the BankAccount 
	 * @return amount
	 */
	
	public double getBalance() {
		return balance;
	}
	
	/**
	 * Print the object BankAccount
	 */
	
	public String toString() {
		
		return this.getClass().getSimpleName() + " Nome: " + this.name + "; Bilancio: " + this.balance + ";";
		
	}
	
	/**
	 * Clone the BankAccount
	 */
	
	public BankAccount clone() {
		
		try {
			
			BankAccount clone = (BankAccount) super.clone();
			return clone;
			
		}
		catch(CloneNotSupportedException e) {
			
			e.printStackTrace();
			
		}
		
		return null;
		
	}
	
	/**
	 * Check if two objects of type BankAccount are equals
	 */
	
	public boolean equals(Object object) {
		
		if(object == null || getClass() != object.getClass()) return false;
		BankAccount otherObject = (BankAccount) object;
		if(otherObject.getName().equals(getName()) && otherObject.getBalance() == getBalance()) {
			
			return true;
			
		}
		else return false;
		
	}
	
}
