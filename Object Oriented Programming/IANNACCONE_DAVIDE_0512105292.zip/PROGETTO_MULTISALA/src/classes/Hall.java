package classes;

import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Hall implements Serializable, Cloneable{
	
	private static final long serialVersionUID = 1L;
	
	private int seatNumber;
	private ArrayList<Show> showArray;
	
	/**
	 * Create a new Hall
	 * @param seatNumber
	 */
	
	public Hall(int seatNumber) {
		
		this.seatNumber = seatNumber;
		this.showArray = new ArrayList<Show>();
		
	}
	
	/**
	 * Return the Array of the shows
	 * @return showArray
	 */
	
	public ArrayList<Show> getShowArray() {
		
		return showArray;
		
	}
	
	/**
	 * Return the number of seats in the hall
	 * @return seatNumber
	 */
	
	public int getSeatNumber() {
		
		return seatNumber;
		
	}
	
	public int searchShow(String data) {
		
		for(int i = 0; i < showArray.size(); i++) {
			
			if(data.equals(showArray.get(i).getTotalDate())) {
				
				return i;
				
			}
			
		}
		 return -1;
		
	}
	
	/**
	 * return true if the show can be added, based on the data, false elsewhere
	 * @param film
	 * @param showData
	 * @param plannedData
	 * @return true/false
	 */
	
	public boolean addShow(Film film, String showData, String plannedData) {
		
		int i;
		
		if(showArray.size() == 0) {
			
			ArrayList<Seat> seats = new ArrayList<Seat>();
			for(i = 0; i < seatNumber; i++) {

				System.out.println("AGGIUNGO");
				seats.add(new Seat());
				
			}
			
			showArray.add(new Show(film, seats, (showData + " " + plannedData)));
			return true;
			
		}
		else {
			
			for(i = 0; i < showArray.size(); i++) {
				
				if((showData + " " + plannedData).equals(showArray.get(i).getTotalDate())){
					
					JOptionPane.showMessageDialog(null, "L'orario di inizio del film � gi� occupato", "Errore", JOptionPane.ERROR_MESSAGE);
					return false;
					
				}
				else {
					
					if(showData.equals(showArray.get(i).getDate())) {
						
						int plannedHour = Integer.parseInt(plannedData.substring(0, 2));
						int otherFilmHour = showArray.get(i).getFilm().getLenght() / 60;
						
						if(plannedHour >= Integer.parseInt(showArray.get(i).getHourDate()) && 
								plannedHour <= (Integer.parseInt(showArray.get(i).getHourDate()) + otherFilmHour)) {
							
							JOptionPane.showMessageDialog(null, "L'orario di inizio del film � occupato da un'altro film", "Errore", JOptionPane.ERROR_MESSAGE);
							return false;
							
						}
						else {
								
							if((plannedHour + (film.getLenght() / 60)) >= Integer.parseInt(showArray.get(i).getHourDate()) &&
									(plannedHour + (film.getLenght() / 60)) >= Integer.parseInt(showArray.get(i).getHourDate() + otherFilmHour)) {
								
								JOptionPane.showMessageDialog(null, "La durata del film dura" + film.getLenght() + " minuti, va ad invadere un'altro film", "Errore", JOptionPane.ERROR_MESSAGE);
								return false;
								
							}
							
						}
						
					}
					
				}
				
			}
			
			ArrayList<Seat> seats = new ArrayList<Seat>();
			for(i = 0; i < seatNumber; i++) {
				
				seats.add(new Seat());
				
			}
			
			String dataAdd = showData + " " + plannedData;
			System.out.println(dataAdd);
			
			showArray.add(new Show(film, seats, dataAdd));
			return true;
			
		}
	
	}
	
}
