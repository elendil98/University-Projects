package classes;

import java.io.Serializable;

public class Film implements Serializable{

	private static final long serialVersionUID = 1L;

	private final String name;
	private final String directorName;
	private final int lenght;
	
	/**
	 * Create a Film class
	 * @param name
	 * @param lenght
	 */
	
	public Film(String name, String directorName, int lenght) {
		
		this.name = name;
		this.directorName = directorName;
		this.lenght = lenght;
		
	}
	
	/**
	 * Return the name of the Film
	 * @return filmName
	 */
	
	public String getName() {
		
		return name;
		
	}
	
	/**
	 * Return the director name of the film
	 * @return directorName
	 */
	
	public String getDirectorName() {
		
		return directorName;
		
	}
	
	/**
	 * Return the film lenght
	 * @return filmStartTime
	 */
	
	public int getLenght() {
		
		return lenght;
		
	}
	
}
