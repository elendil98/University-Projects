package classes;

import java.io.Serializable;


public class Account implements Serializable, Cloneable{

	private static final long serialVersionUID = 1L;
	
	private String username;
	private String password;
	
	/**
	 * Create a new Account
	 * @param username
	 * @param password
	 */
	
	public Account(String username, String password) {
		
		this.username = username;
		this.password = password;
		
	}
	
	/**
	 * return the username of the account
	 * @return username
	 */
	
	public String getUsername() {
		
		return username;
		
	}
	
	/**
	 * return the password of the account
	 * @return password
	 */
	
	public String getPassword() {
		
		return password;
		
	}
	
	/**
	 * Set a new username
	 * @param username
	 */
	
	public void setUsername(String username) {
		
		this.username = username;
		
	}
	
	/**
	 * Set a new passoword
	 * @param password
	 */
	
	public void setPassword(String password) {
		
		this.password = password;
		
	}
	
	/**
	 * set password or username (0 for username, 1 for password
	 * @param credential
	 * @param position
	 */
	
	public void setCredentials(String credential, int position) {
		
		if(position == 0) {
			setUsername(credential);
		}
		if(position == 1) {
			setPassword(credential);
		}
		
	}
	
	/**
	 * Return the account type: true if is manager, false if is client
	 * @param account
	 * @return true:manager; false:client
	 */
	
	public boolean getAccoutType() {
		
		if(this.getClass() != Manager.class) {
			
			return false;
			
		}
		else {
			
			return true;
			
		}
	
	}
	
}
