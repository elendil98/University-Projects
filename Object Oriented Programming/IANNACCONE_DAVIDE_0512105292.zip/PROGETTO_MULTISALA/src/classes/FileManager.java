package classes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class FileManager {
	
	/**
	 * Write an object saveObject in the corrisponding class file name
	 * @param saveObject
	 * @param fileName
	 */
	
	public static <T extends Serializable> void saveFile(Object saveObject) {
		
		File file = new File(saveObject.getClass().getSimpleName());
		
		try {
			
			FileOutputStream outputStream = new FileOutputStream(file);
			ObjectOutputStream objectOutput = new ObjectOutputStream(outputStream);
			
			objectOutput.writeObject(saveObject);
				
			outputStream.close();
			objectOutput.close();
				
			}
		catch(IOException e) {
			e.printStackTrace();
		}
			
	}
	
	/**
	 * Load an Object from a file with the same class name
	 * @param fileType
	 * @return object
	 */
	
	public static <T extends Serializable> Object loadFile(Object loadObject) {
		
		File file = new File(loadObject.getClass().getSimpleName());
		
		if(file.exists()) {
			
			try {
				
				FileInputStream inputStream = new FileInputStream(file);
				ObjectInputStream objectInput = new ObjectInputStream(inputStream);
				
				Object obj = objectInput.readObject();
				
				inputStream.close();
				objectInput.close();
				
				return obj;
		
			} catch(IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		else {
			
			Multiplex multiplex = new Multiplex();
			FileManager.saveFile(multiplex);
			return multiplex;
			
		}
		
		return null;
		
	}
	
}