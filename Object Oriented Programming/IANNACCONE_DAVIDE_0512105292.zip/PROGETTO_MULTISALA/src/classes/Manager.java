package classes;

public class Manager extends Account{

	private static final long serialVersionUID = 1L;

	private final String name;
	private final String surname;
	
	/**
	 * Create a Manager
	 * @param username
	 * @param password
	 * @param name
	 * @param surname
	 */
	
	public Manager(String username, String password, String name, String surname) {
		
		super(username, password);
		this.name = name;
		this.surname = surname;
		
	}
	
	/**
	 * Return the name of the Manager
	 * @return name
	 */
	
	public String getName() {
		
		return name;
		
	}
	
	/**
	 * Return the surname of the Manager
	 * @return surname;
	 */
	
	public String getSurname() {
		
		return surname;
		
	}
	
	/**
	 * Print Manager Class
	 */
	
	public String toString() {
		
		return this.getClass().getSimpleName() + " Nome: " + name + "; Cognome: " + surname + ";";
		
	}
	
}
