package classes;

import java.io.Serializable;
import java.util.ArrayList;

import classes.Seat.Type;

public class Show implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Film film;
	private ArrayList<Seat> seatArray;
	private String data;
	private double price;
	
	/**
	 * Create a new Show
	 * @param film
	 * @param seatArray
	 */
	
	public Show(Film film, ArrayList<Seat> seatArray, String data) {
		
		this.film = film;
		this.seatArray = seatArray;
		this.data = data;
		this.price = 0;
		
	}
	
	/**
	 * return the date show
	 * @return date
	 */
	
	public String getTotalDate() {
		
		return data;
		
	}
	
	public void resetPrice() {
		price = 0;
	}
	
	public void setPrice(Multiplex multiplex, Client client) {
		
		double maxDiscount = 10;
		
		for(int i = 0; i < multiplex.getPoliticsList().size(); i++) {
			
			if(multiplex.getPoliticsList().get(i).isActive()) {
				
				if(multiplex.getPoliticsList().get(i).checkCondition(client)) {
					
					if(10 - multiplex.getPoliticsList().get(i).getDiscount() < maxDiscount) {
						maxDiscount = 10 - multiplex.getPoliticsList().get(i).getDiscount();
					}
				
				}
				
			}
			
		}
		
		price += maxDiscount;
			
	}
	
	public double getPrice() {
		
		return price;	
		
	}
	
	public String getDate() {
		
		return data.substring(0, 10);
		
	}
	
	public String getHourDate() {
		
		return data.substring(11, 13);
		
	}
	
	public String getMinuteDate() {
		
		return data.substring(14);
		
	}
	
	/**
	 * Return the current film in the show
	 * @return film
	 */
	
	public Film getFilm() {
		
		return film;
		
	}
	
	public boolean isAvailable(String currentDate) {
		
		int currentDateYear = Integer.parseInt(currentDate.substring(0, 4));
		int currentDateMonth = Integer.parseInt(currentDate.substring(5, 7));
		int currentDateDay = Integer.parseInt(currentDate.substring(8, 10));
		int currentDateHour = Integer.parseInt(currentDate.substring(11, 13));
		int showDateYear = Integer.parseInt(data.substring(0, 4));
		int showDateMonth = Integer.parseInt(data.substring(5, 7));
		int showDateDay = Integer.parseInt(data.substring(8, 10));
		int showDateHour = Integer.parseInt(data.substring(11, 13));
		
		if(showDateYear < currentDateYear || showDateMonth < currentDateMonth || showDateDay < currentDateDay) {
			return false;
		}
		else {
			if(showDateYear > currentDateYear || showDateMonth > currentDateMonth || showDateDay > currentDateDay) {
				return true;
			}
			else {
				
				if(showDateHour > currentDateHour) {
					return true;
				}
				else {
					return false;
				}
				
			}
		}
		
	}
	
	public ArrayList<Seat> getSeatList() {
		return seatArray;
	}
	
	/**
	 * Return the Seat in the hall in the current posistion
	 * @param index
	 * @return seat
	 */
	
	public Seat getIndexSeat(int index) {
		
		if(index > seatArray.size()) return null;
		else return seatArray.get(index);
		
	}

	/**
	 * return the number of available seats in the hall
	 * @return availableSeats
	 */
	
	public int getAvailableSeatNumber() {
		
		int seats = 0;
		
		for(int i = 0; i < seatArray.size(); i++) {
			
			if(seatArray.get(i).getType() == Type.DISPONIBILE) {
				
				seats++;
				
			}
			
		}
		return seats;
		
	}
	
	/**
	 * return the number of prenoted seats in the hall
	 * @return prenotedSeats
	 */
	
	public int getPrenotedSeatNumber() {
		
		int seats = 0;
		
		for(int i = 0; i < seatArray.size(); i++) {
			
			if(seatArray.get(i).getType() == Type.PRENOTATO) {
				
				seats++;
				
			}
			
		}
		return seats;
		
	}

	/**
	 * return the number of occupied seats in the hall
	 * @return occupiedSeats
	 */
	
	public int getOccupiedSeatNumber() {
		
		int seats = 0;
		
		for(int i = 0; i < seatArray.size(); i++) {
			
			if(seatArray.get(i).getType() == Type.OCCUPATO) {
				
				seats++;
				
			}
			
		}
		return seats;
		
	}
	
	public String toString() {
		
		return "Nome film: " + film.getName() + " Regista: " + film.getDirectorName() + " Minuti Durata:" +  film.getLenght() + " Data: " + data + "\n";
		
	}
	
}
