package classes;

import java.io.Serializable;

public class Seat implements Serializable{

	private static final long serialVersionUID = 1L;
	
	public enum Type{
		DISPONIBILE, PRENOTATO, OCCUPATO
	}
	private Type type;
	
	
	/**
	 * Create a new Seat
	 * @param number
	 */
	
	public Seat() {
	
		type = Type.DISPONIBILE;
		
	}
	
	/**
	 * Return a boolean, check if it's available (true) or not(false)
	 * @return available
	 */
	
	public Type getType() {
		
		return type;
		
	}
	
	public void setType(Type type) {
		
		this.type = type;
		
	}
	
}
