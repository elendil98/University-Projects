package classes;

import java.util.ArrayList;

public class Client extends Account {

	private static final long serialVersionUID = 1L;

	private final String name;
	private final String surname;
	private int age;
	private BankAccount bankAccount;
	private ArrayList<Seat> bookingSeat;
	
	/**
	 * Create a new Client
	 * @param username
	 * @param password
	 * @param name
	 * @param surname
	 * @param age
	 * @param bankAccount
	 */
	
	public Client(String username, String password, String name, String surname, int age, BankAccount bankAccount) {
		
		super(username, password);
		this.name = name;
		this.surname = surname;
		this.age = age;
		this.bankAccount = bankAccount;
		bookingSeat = new ArrayList<Seat>();
		
	}
	
	/**
	 * Return the name of the Client
	 * @return name
	 */
	
	public String getName() {
		
		return name;
		
	}
	
	/**
	 * Return the surname of the Client
	 * @return surname
	 */
	
	public String getSurname() {
		
		return surname;
		
	}
	
	/**
	 * Return the age of the Client
	 * @return age
	 */
	
	public int getAge() {
		
		return age;
	}
	
	/**
	 * Returnt the BankAccount of the Client
	 * @return bankAccount
	 */
	
	public BankAccount getBankAccount() {
		
		return bankAccount;
		
	}
	
	/**
	 * add a booking Seat
	 * @param seat
	 */
	
	public void addBookingSeat(Seat seat) {
		bookingSeat.add(seat);
	}
	
	/**
	 * return the list of all booking seat
	 * @return bookingSeat
	 */
	
	public ArrayList<Seat> getBookingSeat() {
		return bookingSeat;
	}
	
	/**
	 * Reset all booking seat of the client (used when buyed tickets)
	 */
	
	public void resetBookingSeat() {
		bookingSeat = new ArrayList<Seat>();
	}
	
	/**
	 * Print Client Class
	 */
	
	public String toString() {
		
		return this.getClass().getSimpleName() + " Nome: " + name + "; Cognome: " + surname + "; Et�: " + age + "; " + bankAccount;
		
	}

}
