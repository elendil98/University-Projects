package classes;

import java.io.Serializable;
import java.util.ArrayList;

import politics.AgePolitic;
import politics.OverAgePolitic;
import politics.Politics;
import politics.UsualCustomerPolitic;

public class Multiplex implements Serializable{

	private static final long serialVersionUID = 1L;

	private String name;
	private ArrayList<Hall> hallArray;
	private ArrayList<Account> accountList;
	private ArrayList<Film> filmList;
	private ArrayList<Politics> politicList;
	private double entry;
	
	/**
	 * Create the Multiplex
	 * @param name
	 * @param manager
	 * @param hallArray
	 */
	
	public Multiplex() {
		
		this.name = "Multiplex";
		this.hallArray = new ArrayList<Hall>();
		this.accountList = new ArrayList<Account>();
		this.filmList = new ArrayList<Film>();
		politicList = createPoliticList();
		entry = 0;
		
	}
	
	/**
	 * create politics in the politics package and insert it here
	 * @return politics list
	 */
	
	public ArrayList<Politics> createPoliticList() {
		
		ArrayList<Politics> politicList = new ArrayList<Politics>();
		politicList.add(new AgePolitic());
		politicList.add(new OverAgePolitic());
		politicList.add(new UsualCustomerPolitic());
		//Insert next politic here when created
		
		return politicList;
		
	}
	
	public void addEntry(double entry) {
		this.entry += entry;
	}
	
	/**
	 * get total entry of the multiplex
	 * @return entry
	 */
	
	public double getTotalEntry() {
		return entry;
	}
	
	/**
	 * refresh the politics list if the file is alredy saved
	 */
	
	public void refreshPoliticList() {
		
		this.politicList = createPoliticList();
		
	}
	
	/**
	 * return the politic List, for use
	 * @return politicList
	 */
	
	public ArrayList<Politics> getPoliticsList() {
		
		return politicList;
		
	}
	
	/**
	 * Return the name of the multiplex
	 * @return name
	 */
	
	public String getName() {
		
		return name;
		
	}

	/**
	 * Add a Hall in the multiplex
	 * @param hall
	 */
	
	public void addHall(Hall hall) {
		
		hallArray.add(hall);
		
	}
	
	/**
	 * add a film to the list of film in the multiplex
	 * @param film
	 */
	
	public boolean addFilm(Film film) {
		
		for(int i = 0; i < filmList.size(); i++) {
			
			if(film.getName().equals(filmList.get(i).getName())) {
				
				return false;
				
			}
			
		}
		
		filmList.add(film);
		return true;
	}
	
	/**
	 * Return the Array of Every halls in the multiplex (Used to get ne halls number most of)
	 * @return hallArray
	 */
	
	public ArrayList<Hall> getArrayHalls() {
	
		return hallArray;
		
	}
	
	/**
	 * return the account list created in the multiplex
	 * @return accountList
	 */

	public ArrayList<Account> getAccountList() {
		
		return accountList;
		
	}
	
	/**
	 * return the list of all added films in the multiplex
	 * @return filmList
	 */
	
	public ArrayList<Film> getFilmList() {
		
		return filmList;
		
	}
	
	/**
	 * return the film with the current filmName name
	 * @param filmName
	 * @return film
	 */
	
	public Film getFilmName(String filmName) {
		
		for(int i = 0; i < filmList.size(); i++) {
			
			if(filmList.get(i).getName().equals(filmName)) {
				
				return filmList.get(i);
				
			}
			
		}
		
		return null;
		
	}
	
	/**
	 * Change the multiplex name
	 * @param name
	 */
	
	public void setName(String name) {
		
		this.name = name;
		
	}
	
	/**
	 * Search the account in the account list, use username and password to search
	 * @param list
	 * @param searchUsername
	 * @param searchPassword
	 * @return search the account with the username and password
	 */
	
	public Account searchAccount(String searchUsername, String searchPassword) {
		
		for(int i = 0; i < accountList.size(); i++) {
			
			if(searchUsername.equals(accountList.get(i).getUsername()) && searchPassword.equals(accountList.get(i).getPassword())) {
				
				return accountList.get(i);
				
			}
			
		}
		
		return null;
		
	}
	
	/**
	 * return the index of the searched username and password account
	 * @param list
	 * @param searchUsername
	 * @param searchPassword
	 * @return i or 0
	 */
	
	public int searchAccountIndex(String searchUsername, String searchPassword) {
		
		for(int i = 0; i < accountList.size(); i++) {

			if(searchUsername.equals(accountList.get(i).getUsername()) && searchPassword.equals(accountList.get(i).getPassword())) {				
				return i;
			}
			
		}
		
		return -1;
		
	}
	
	public boolean addAccount(Account account) {
		
		if(searchAccount(account.getUsername(), account.getPassword()) == null) {
			
			accountList.add(account);
			FileManager.saveFile(this);
			return true;
			
		}
		
		return false;
		
	}
	
	public Account removeAccount(int index) {
		
		Account removedAccount = accountList.remove(index);
		FileManager.saveFile(this);
		return removedAccount;
		
	}
	
	public void removeAccount(Account account) {
		
		accountList.remove(account);
		FileManager.saveFile(this);
		
	}
	
	public void removeFilm(int index) {
		
		filmList.remove(index);
		
	}
	
}
