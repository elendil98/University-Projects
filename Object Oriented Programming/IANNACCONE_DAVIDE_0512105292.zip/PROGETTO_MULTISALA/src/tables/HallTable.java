package tables;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import classes.Multiplex;

public class HallTable extends JTabbedPane{

	private static final long serialVersionUID = 1L;

	private final static String[] hallColumns = {"Numero Sala", "Numero Posti", "Numero Spettacoli"};
	private final static String[] showColumns = {"Sala", "Film" , "Durata", "Posti Disponibili", "Posti Prenotati", "Posti Occupati", "Data"};
	private JTable hallTable;
	private JTable showTable;
	private String[][] hallRowData;
	private String[][] showRowData;
	
	public HallTable(Multiplex multiplex) {
		
		hallRowData = new String[multiplex.getArrayHalls().size()][3];
		
		int totalShowNumber = 0;
		
		for(int i = 0; i < multiplex.getArrayHalls().size(); i++) { 
			
			hallRowData[i][0] = "Sala " + (i + 1);
			hallRowData[i][1] = "" + multiplex.getArrayHalls().get(i).getSeatNumber();
			hallRowData[i][2] = "" + multiplex.getArrayHalls().get(i).getShowArray().size();
			totalShowNumber += multiplex.getArrayHalls().get(i).getShowArray().size();
			
		}
		
		if(totalShowNumber > 0) {
			
			showRowData = new String[totalShowNumber][7];
			
			int positionRow = 0;
			
			for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
				
				for(int j = 0; j < multiplex.getArrayHalls().get(i).getShowArray().size(); j++) {
					
					showRowData[positionRow][0] = "Sala " + (i + 1);
					showRowData[positionRow][1] = multiplex.getArrayHalls().get(i).getShowArray().get(j).getFilm().getName();
					showRowData[positionRow][2] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getFilm().getLenght();
					showRowData[positionRow][3] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getAvailableSeatNumber();
					showRowData[positionRow][4] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getPrenotedSeatNumber();
					showRowData[positionRow][5] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getOccupiedSeatNumber();
					showRowData[positionRow][6] = multiplex.getArrayHalls().get(i).getShowArray().get(j).getTotalDate();
					positionRow++;
					
				}
				
			}
			
			showTable = new JTable(showRowData, showColumns) {
				private static final long serialVersionUID = 1L;
				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
			
		}
		
		hallTable = new JTable(hallRowData, hallColumns) {
			private static final long serialVersionUID = 1L;
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		JScrollPane hallPane = new JScrollPane(hallTable);
		JScrollPane showPane = new JScrollPane(showTable);
		
		this.addTab("Lista Sale", null, hallPane, "Lista delle Sale del Multisala");
		this.addTab("Lista Spettacoli", null, showPane , "Lista degli Spettacoli in tutte le sale");
		
		
	}
	
	public JTable getHallTable() {
		return hallTable;
	}
	
	public JTable getShowTable() {
		return showTable;
	}
	
	public String[][] getHallRowData() {
		
		return hallRowData;
		
	}

	public String[][] getShowRowData() {
		
		return showRowData;
		
	}
	
	public void addListener(JButton buttonView, JButton manageShow, JButton weeklyProgram) {
		
		ChangeListener changeListener = new ChangeListener() {
			
		      public void stateChanged(ChangeEvent changeEvent) {
		    	  
		        HallTable sourceTabbedPane = (HallTable) changeEvent.getSource();
		        
		        if(sourceTabbedPane.getSelectedIndex() == 1) {
		        	manageShow.setVisible(true);
		        	buttonView.setVisible(false);
		        	weeklyProgram.setVisible(false);
		        }
		        else {
		        	manageShow.setVisible(false);
		        	buttonView.setVisible(true);
		        	weeklyProgram.setVisible(true);
		        }
		        
		      }
		      
	    };
	    this.addChangeListener(changeListener);
	}
	
}
