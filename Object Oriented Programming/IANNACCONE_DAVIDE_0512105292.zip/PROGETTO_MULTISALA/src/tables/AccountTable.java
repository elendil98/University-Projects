package tables;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import classes.Client;
import classes.Manager;
import classes.Multiplex;

public class AccountTable extends JTabbedPane{
	
	private final static String[] managerColumns = {"Username", "Password", "Nome", "Cognome"};
	private final static String[] clientColumns = {"Username", "Password", "Nome", "Cognome", "Anni", "Saldo"};
	private JTable managerTable;
	private JTable clientTable;
	private String[][] managerRowData;
	private String[][] clientRowData;
	
	private static final long serialVersionUID = 1L;

	public AccountTable(Multiplex multiplex) {
		
		ImageIcon managerIcon = new ImageIcon(this.getClass().getResource("/images/manager.png"));
		ImageIcon clientIcon = new ImageIcon(this.getClass().getResource("/images/client.png"));
		
		int managerNumber = 0;
		int clientNumber = 0;
		int accountNumber = 0;
		
		for(accountNumber = 0; accountNumber < multiplex.getAccountList().size(); accountNumber++) {
			
			if(multiplex.getAccountList().get(accountNumber).getAccoutType()) {
				managerNumber++;
			}
			else {
				clientNumber++;
			}
			
		}
		
		managerRowData = new String[managerNumber][4];
		clientRowData = new String[clientNumber][6];
		
		managerNumber = 0;
		clientNumber = 0;
		
		for(accountNumber = 0; accountNumber < multiplex.getAccountList().size(); accountNumber++) {
			
			if(multiplex.getAccountList().get(accountNumber).getAccoutType()) {
				
				managerRowData[managerNumber][0] = ((Manager) multiplex.getAccountList().get(accountNumber)).getUsername();
				managerRowData[managerNumber][1] = ((Manager) multiplex.getAccountList().get(accountNumber)).getPassword();
				managerRowData[managerNumber][2] = ((Manager) multiplex.getAccountList().get(accountNumber)).getName();
				managerRowData[managerNumber][3] = ((Manager) multiplex.getAccountList().get(accountNumber)).getSurname();
				
				managerNumber++;
				
			}
			else {
				
				clientRowData[clientNumber][1] = "";
				
				for(int j = 0; j < (multiplex.getAccountList().get(accountNumber).getPassword().length()); j++) {
					clientRowData[clientNumber][1] += "*";
				}
				
				clientRowData[clientNumber][0] = ((Client) multiplex.getAccountList().get(accountNumber)).getUsername();
				clientRowData[clientNumber][2] = ((Client) multiplex.getAccountList().get(accountNumber)).getName();
				clientRowData[clientNumber][3] = ((Client) multiplex.getAccountList().get(accountNumber)).getSurname();
				clientRowData[clientNumber][4] = "" + ((Client) multiplex.getAccountList().get(accountNumber)).getAge();
				clientRowData[clientNumber][5] = "" + ((Client) multiplex.getAccountList().get(accountNumber)).getBankAccount().getBalance();
				
				clientNumber++;
				
			}
			
		}
		
		managerTable = new JTable(managerRowData, managerColumns) {
			private static final long serialVersionUID = 1L;
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		JScrollPane managerPane = new JScrollPane(managerTable);
		
		clientTable = new JTable(clientRowData, clientColumns);
		clientTable.setEnabled(false);
		JScrollPane clientPane = new JScrollPane(clientTable);
		
		this.addTab("Account Manager", managerIcon, managerPane, "Lista degli account Manager");
		this.addTab("Account Clienti", clientIcon, clientPane, "Lista degli account Clienti");
		

	}

	public JTable getManagerTable() {
		
		return managerTable;
		
	}
	
	public JTable getClientTable() {
		
		return clientTable;
		
	}
	
	public String[][] getManagerRowData() {
		
		return managerRowData;
		
	}
	
	public void addListener(JPanel changePanel) {
		
		ChangeListener changeListener = new ChangeListener() {
			
		      public void stateChanged(ChangeEvent changeEvent) {
		    	  
		        AccountTable sourceTabbedPane = (AccountTable) changeEvent.getSource();
		        
		        if(sourceTabbedPane.getSelectedIndex() == 1) {
		        	changePanel.setVisible(false);
		        }
		        else {
		        	changePanel.setVisible(true);
		        }
		        
		      }
		      
	    };
		
	    this.addChangeListener(changeListener);
		
	}
	
}
