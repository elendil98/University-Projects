package tables;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import classes.Client;
import classes.Multiplex;

public class ShowTable extends JTabbedPane{

	private static final long serialVersionUID = 1L;

	private static SimpleDateFormat currentDate = new SimpleDateFormat("yyyy/MM/dd HH:mm");
	Date date;
	
	private final static String[] allShowColumns = {"Sala", "Film" , "Durata", "Data"};
	private final static String[] availableShowColumns = {"Sala", "Film" , "Durata", "Posti Disponibili", "Posti Prenotati", "Posti Occupati", "Data", "Prezzo"};
	private JTable allShowTable;
	private JTable availableShowTable;
	private String[][] allShowRowData;
	private String[][] availableShowRowData;
	
	public ShowTable(Multiplex multiplex, Client client) {
		
		date = new Date();
		
		int totalShowNumber = 0;
		
		for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
			totalShowNumber += multiplex.getArrayHalls().get(i).getShowArray().size();
		}
		
		if(totalShowNumber > 0) {
			
			allShowRowData = new String[totalShowNumber][4];
			availableShowRowData = new String[totalShowNumber][8];
			
			int positionRow = 0;
			int positionAvailableRow = 0;
			
			for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
				
				for(int j = 0; j < multiplex.getArrayHalls().get(i).getShowArray().size(); j++) {
					
					allShowRowData[positionRow][0] = "Sala " + (i + 1);
					allShowRowData[positionRow][1] = multiplex.getArrayHalls().get(i).getShowArray().get(j).getFilm().getName();
					allShowRowData[positionRow][2] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getFilm().getLenght();
					allShowRowData[positionRow][3] = multiplex.getArrayHalls().get(i).getShowArray().get(j).getTotalDate();
					positionRow++;
					
					if(multiplex.getArrayHalls().get(i).getShowArray().get(j).isAvailable(currentDate.format(date))) {
						
						availableShowRowData[positionAvailableRow][0] = "Sala " + (i + 1);
						availableShowRowData[positionAvailableRow][1] = multiplex.getArrayHalls().get(i).getShowArray().get(j).getFilm().getName();
						availableShowRowData[positionAvailableRow][2] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getFilm().getLenght();
						availableShowRowData[positionAvailableRow][3] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getAvailableSeatNumber();
						availableShowRowData[positionAvailableRow][4] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getPrenotedSeatNumber();
						availableShowRowData[positionAvailableRow][5] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getOccupiedSeatNumber();
						availableShowRowData[positionAvailableRow][6] = multiplex.getArrayHalls().get(i).getShowArray().get(j).getTotalDate();
						availableShowRowData[positionAvailableRow][7] = "" + multiplex.getArrayHalls().get(i).getShowArray().get(j).getPrice();
						positionAvailableRow++;
								
					}
					
				}
				
			}
			allShowTable = new JTable(allShowRowData, allShowColumns);
			allShowTable.setEnabled(false);
			
			availableShowTable = new JTable(availableShowRowData, availableShowColumns) {
				private static final long serialVersionUID = 1L;
				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
	
		}
		
		JScrollPane allShowPane = new JScrollPane(allShowTable);
		JScrollPane availableShowPane = new JScrollPane(availableShowTable);
		
		this.addTab("Programmazione Settimanale", null, allShowPane, "Lista degli Spettacoli in tutte le sale");
		this.addTab("Programmazione Disponibile", null, availableShowPane , "Lista degli Spettacoli disponibili in tutte le sale");
		
	}
	
	public JTable getAllShowTable() {
		return allShowTable;
	}
	
	public JTable getAvailableShowTable() {
		return availableShowTable;
	}
	
	public String[][] getAllShowRowData() {
		
		return allShowRowData;
		
	}

	public String[][] getAvailableShowRowData() {
		
		return availableShowRowData;
		
	}

	public void addListener(JPanel buttonPanel) {
		
		ChangeListener changeListener = new ChangeListener() {
			
		      public void stateChanged(ChangeEvent changeEvent) {
		    	  
		        ShowTable sourceTabbedPane = (ShowTable) changeEvent.getSource();
		        
		        if(sourceTabbedPane.getSelectedIndex() == 1) {
		        	buttonPanel.setVisible(true);
		        }
		        else {
		        	buttonPanel.setVisible(false);
		        }
		        
		      }
		      
	    };
	    this.addChangeListener(changeListener);
	}
	
	
}
