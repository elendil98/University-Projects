package tables;

import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import classes.Multiplex;

public class FilmTable extends JTabbedPane{

	private static final long serialVersionUID = 1L;

	private final static String[] filmColumns = {"Nome Film", "Regista", "Durata (Minuti)"};
	private JTable filmTable;
	private String[][] filmRowData;
	
	public FilmTable(Multiplex multiplex) {
		
		filmRowData = new String[multiplex.getFilmList().size()][3];
		
		
		for(int i = 0; i < multiplex.getFilmList().size(); i++) { 
			
			filmRowData[i][0] = multiplex.getFilmList().get(i).getName();
			filmRowData[i][1] = multiplex.getFilmList().get(i).getDirectorName();
			filmRowData[i][2] = "" + multiplex.getFilmList().get(i).getLenght();
			
		}
		
		filmTable = new JTable(filmRowData, filmColumns) {
			private static final long serialVersionUID = 1L;
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		JScrollPane filmPane = new JScrollPane(filmTable);
		
		this.addTab("Lista Film", null, filmPane, "Lista dei Film Aggiunti");
		
	}
	
	public JTable getFilmTable() {
		
		return filmTable;
		
	}
	
	public String[][] getFilmRowData() {
		
		return filmRowData;
		
	}
	
}
