package exception;

import java.io.IOException;

public class FileManagerLoadException extends IOException {

	private static final long serialVersionUID = 1L;

	public FileManagerLoadException() {
		
		super();
		
	}
	
	public FileManagerLoadException(String s) {
		
		super(s);
		
	}
	
}
