package exception;

import java.io.IOException;

public class PostoIndisponibileException extends IOException{

	private static final long serialVersionUID = 1L;

	public PostoIndisponibileException() {
		super();
	}
	
	public PostoIndisponibileException(String s) {
		super(s);
	}
	
}
