package exception;

public class NoPoliticException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public NoPoliticException() {
		
		super();
		
	}
	
	public NoPoliticException(String s) {
		
		super(s);
		
	}
	
}
