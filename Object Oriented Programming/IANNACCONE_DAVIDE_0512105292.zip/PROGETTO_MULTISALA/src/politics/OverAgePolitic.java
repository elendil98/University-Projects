package politics;

import classes.Client;

public class OverAgePolitic extends Politics{

	private static final long serialVersionUID = 1L;
	
	private String name;
	private double discount;
	private boolean active;
	
	public OverAgePolitic() {
		
		this.name = "Et� superiore ai 60 anni" ;
		this.discount = 0.5;
		active = false;
		
	}
	
	public String getName() {
		return name;
	}
	
	public boolean isActive() {
		return active;
	}
	
	public double getDiscount() {
		return discount;
	}
	
	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean checkCondition(Object object) {
		Client client = (Client) object;
		
		if(client.getAge() > 60) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
}
