package politics;

import classes.Client;

public class AgePolitic extends Politics {
	
	private static final long serialVersionUID = 1L;
	
	private String name;
	private double discount;
	private boolean active;
	
	public AgePolitic() {
		
		this.name = "Anni Inferiori a 18";
		this.discount = 2.5;
		active = false;
		
	}
	
	public String getName() {
		return name;
	}
	
	public boolean isActive() {
		return active;
	}
	
	public double getDiscount() {
		return discount;
	}
	
	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean checkCondition(Object object) {
		Client client = (Client) object;
		
		if(client.getAge() < 18) {
			return true;
		}
		else {
			return false;
		}
	
	}

}
