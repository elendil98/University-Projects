package politics;

import java.io.Serializable;

public abstract class Politics implements Serializable{
	
	/**
	 * Add politics in Multiplex when Created
	 * use method createPoliticList
	 */
	
	private static final long serialVersionUID = 1L;
	
	public abstract String getName();
	public abstract boolean isActive();
	public abstract double getDiscount();
	public abstract void setActive(boolean active);
	public abstract boolean checkCondition(Object object);
	
}
