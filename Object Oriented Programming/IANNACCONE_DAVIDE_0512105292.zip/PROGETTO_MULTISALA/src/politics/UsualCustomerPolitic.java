package politics;

import classes.Client;

public class UsualCustomerPolitic extends Politics{

	private static final long serialVersionUID = 1L;
	
	private String name;
	private double discount;
	private boolean active;
	
	public UsualCustomerPolitic() {
		
		this.name = "Cliente Abituale (Saldo maggiore di 300)";
		this.discount = 1.5;
		active = false;
		
	}
	
	public String getName() {
		return name;
	}
	
	public boolean isActive() {
		return active;
	}
	
	public double getDiscount() {
		return discount;
	}
	
	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean checkCondition(Object object) {
		
		Client client = (Client) object;
		
		if(client.getBankAccount().getBalance() > 300) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
}
