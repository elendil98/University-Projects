package menus;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import classes.FileManager;
import classes.Film;
import classes.Multiplex;
import tables.FilmTable;

public class FilmMenu extends JMenu{

	private static final long serialVersionUID = 1L;
	
	private JMenuItem menuItemViewFilm;
	private JMenuItem menuItemAddFilm;
	private JPanel addFilmPanel;
	
	public FilmMenu(Multiplex multiplex, JPanel mainPanel) {
		
		class ViewFilmListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(multiplex.getFilmList().size() < 1) {
					
					JOptionPane.showMessageDialog(mainPanel, "Nessun film trovato nel multisala", "Errore", JOptionPane.ERROR_MESSAGE);
					
				}
				else {
					
					mainPanel.removeAll();
					mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
					JPanel filmPanel= new JPanel();
					FilmTable filmTable = new FilmTable(multiplex);
					mainPanel.add(filmTable);
					mainPanel.setBackground(Color.WHITE);
					
					filmPanel = createFilmPanel(filmTable, multiplex, mainPanel);
					mainPanel.add(filmPanel);
						
					mainPanel.repaint();
					mainPanel.revalidate();
					
				}
				
			}
			
		}
		
		class AddFilmListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				mainPanel.removeAll();
				mainPanel.revalidate();
				mainPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
				
				addFilmPanel = createAddFilmPanel(multiplex);
				
				mainPanel.setLayout(new GridBagLayout());
				mainPanel.add(addFilmPanel);
				mainPanel.repaint();
				
			}
			
		}
		
		this.setText("Film");
		
		menuItemViewFilm = new JMenuItem("Lista Film");
		menuItemViewFilm.addActionListener(new ViewFilmListener());
		
		menuItemAddFilm = new JMenuItem("Aggiungi Film");
		menuItemAddFilm.addActionListener(new AddFilmListener());
		
		add(menuItemViewFilm);
		add(menuItemAddFilm);
		
		
	}
	
	private JPanel createAddFilmPanel(Multiplex multiplex) { 
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		JTextField fieldName = new JTextField(10);
		JTextField fieldDirector = new JTextField(10);
		JTextField fieldLenght = new JTextField(10);
		
		JPanel insertNamePanel = new JPanel();
		insertNamePanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		insertNamePanel.setLayout(new GridLayout(2, 1));
		JLabel nameLabel = new JLabel("Inserisci Nome");
		nameLabel.setForeground(new Color(0.8F, 0.8F, 0.8F));
		insertNamePanel.add(nameLabel);
		insertNamePanel.add(fieldName);
		
		JPanel insertDirectorPanel = new JPanel();
		insertDirectorPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		insertDirectorPanel.setLayout(new GridLayout(2, 1));
		JLabel directorLabel = new JLabel("Inserisci Regista");
		directorLabel.setForeground(new Color(0.8F, 0.8F, 0.8F));
		insertDirectorPanel.add(directorLabel);
		insertDirectorPanel.add(fieldDirector);
	
		JPanel insertLenghtPanel = new JPanel();
		insertLenghtPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		insertLenghtPanel.setLayout(new GridLayout(2, 1));
		JLabel lenghtLabel = new JLabel("Inserisci Durata (Minuti)");
		lenghtLabel.setForeground(new Color(0.8F, 0.8F, 0.8F));
		insertLenghtPanel.add(lenghtLabel);
		insertLenghtPanel.add(fieldLenght);
		
		panel.setLayout(new GridLayout(2, 3));
		
		JPanel voidPanel1 = new JPanel();
		voidPanel1.setBackground(new Color(0.3F, 0.3F, 0.3F));
		JPanel voidPanel2 = new JPanel();
		voidPanel2.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		class AddFilmListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(Integer.parseInt(fieldLenght.getText()) < 30 || Integer.parseInt(fieldLenght.getText()) > 600 || fieldName.getText().isEmpty() || fieldDirector.getText().isEmpty() || fieldLenght.getText().isEmpty()) {
					
					JOptionPane.showMessageDialog(panel, "Durta del film superiore a 600 minuti o campi non rimepiti", "Errore", JOptionPane.ERROR_MESSAGE);
					
				}
				else {
					
					Film film = new Film(fieldName.getText(), fieldDirector.getText(), Integer.parseInt(fieldLenght.getText()));
					
					if(multiplex.addFilm(film)) {
						
						FileManager.saveFile(multiplex);
						JOptionPane.showMessageDialog(panel, "Film inserito con successo", "Successo", JOptionPane.INFORMATION_MESSAGE);
						
					}
					else {
						
						JOptionPane.showMessageDialog(panel, "Film con questo nome esiste gi�", "Errore", JOptionPane.ERROR_MESSAGE);
					}
					
				}
				
			}
			
		}
		
		JButton addFilmButton = new JButton("Conferma");
		addFilmButton.addActionListener(new AddFilmListener());
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		buttonPanel.add(addFilmButton);
		
		panel.add(insertNamePanel);
		panel.add(insertDirectorPanel);
		panel.add(insertLenghtPanel);
		panel.add(voidPanel1);
		panel.add(buttonPanel);
		panel.add(voidPanel2);
		
		return panel;
		
	}
	
	private JPanel createFilmPanel(FilmTable filmTable, Multiplex multiplex, JPanel mainPanel) {
		
		class DeleteFilmListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				int pos = filmTable.getFilmTable().getSelectedRow();
				
				if(pos < 0) {
					JOptionPane.showMessageDialog(mainPanel, "Nessuna riga selezionata", "Errore", JOptionPane.ERROR_MESSAGE);
				}
				else {
						
					multiplex.removeFilm(pos);
					filmTable.getFilmRowData()[pos][0] = "";
					filmTable.getFilmRowData()[pos][1] = "";
					filmTable.getFilmRowData()[pos][2] = "";
					FileManager.saveFile(multiplex);
					filmTable.repaint();
					
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		JButton deleteFilmButton = new JButton("Elimina");
		deleteFilmButton.addActionListener(new DeleteFilmListener());
		
		panel.add(deleteFilmButton);
		
		return panel;
		
	}
	
}
