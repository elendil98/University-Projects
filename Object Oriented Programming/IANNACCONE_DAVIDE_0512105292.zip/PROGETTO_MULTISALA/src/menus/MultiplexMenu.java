package menus;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import classes.FileManager;
import classes.Hall;
import classes.Multiplex;

public class MultiplexMenu extends JMenu{

	private static final long serialVersionUID = 1L;
	
	private JPanel textPanel;
	private JPanel changePanel;
	
	public MultiplexMenu(Multiplex multiplex, JPanel mainPanel) {
		
		class ShowMultiplexListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				mainPanel.removeAll();
				mainPanel.revalidate();
				mainPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
				textPanel = createShowMultiplexPanel(multiplex);
				
				mainPanel.setLayout(new GridBagLayout());
				mainPanel.add(textPanel);
				mainPanel.repaint();
				
			}
			
		}
		
		class ChangeMultiplexListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				mainPanel.removeAll();
				mainPanel.revalidate();
				mainPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
				
				changePanel = createChangeMultiplexPanel(multiplex);
				
				mainPanel.setLayout(new GridBagLayout());
				mainPanel.add(changePanel);
				mainPanel.repaint();
				
			}
			
		}
		
		this.setText("Multiplex");
		
		JMenuItem menuItemShowMultiplex = new JMenuItem("Visualizza");
		menuItemShowMultiplex.addActionListener(new ShowMultiplexListener());
		JMenuItem menuItemChangeMultiplex = new JMenuItem("Modifica");
		menuItemChangeMultiplex.addActionListener(new ChangeMultiplexListener());
		
		add(menuItemShowMultiplex);
		add(menuItemChangeMultiplex);
	
	}
	
	public JPanel createChangeMultiplexPanel(Multiplex multiplex) {
		
		JPanel panel = new JPanel();
		
		JLabel labelMultiplexName = new JLabel(multiplex.getName());
		labelMultiplexName.setForeground(new Color(0.8F, 0.8F, 0.8F));
		labelMultiplexName.setFont(new Font("Arial", Font.BOLD, 16));
		
		JPanel panelName = new JPanel();
		panelName.setLayout(new GridBagLayout());
		panelName.setBackground(new Color(0.3F, 0.3F, 0.3F));
		panelName.add(labelMultiplexName);
		
		JLabel labelChangeName = new JLabel("        Inserire nuovo nome:");
		labelChangeName.setForeground(new Color(0.8F, 0.8F, 0.8F));
		JLabel labelSeatNumber = new JLabel("        Inserisci Numero Posti");
		labelSeatNumber.setForeground(new Color(0.8F, 0.8F, 0.8F));
		
		JTextField fieldNewName = new JTextField(5);
		JTextField fieldSeatNumber = new JTextField(5);
		JButton buttonChangeName = new JButton("Cambia Nome Multisala");
		JButton buttonAddHall = new JButton("Aggiungi Sala " + (multiplex.getArrayHalls().size() + 1));
		
		class AddHallListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(fieldSeatNumber.getText().equals("")) {
					
					JOptionPane.showMessageDialog(buttonAddHall, "Non � stato inserito nulla come numero di Sedie", "Errore", JOptionPane.ERROR_MESSAGE);
					
				}
				else {
					
					if(Integer.parseInt(fieldSeatNumber.getText()) < 30 || Integer.parseInt(fieldSeatNumber.getText()) > 120) {
						
						JOptionPane.showMessageDialog(buttonAddHall, "Numero di posti inferiore a 30 o superiore a 120", "Attenzione", JOptionPane.WARNING_MESSAGE);
						
					}
					else {
						
						multiplex.addHall(new Hall(Integer.parseInt(fieldSeatNumber.getText())));
						FileManager.saveFile(multiplex);
						buttonAddHall.setText("Aggiungi Sala " + (multiplex.getArrayHalls().size() + 1));
						JOptionPane.showMessageDialog(buttonAddHall, "Inserita nuova Sala al: " + multiplex.getName(), "Nuova Sala Inserita", JOptionPane.INFORMATION_MESSAGE);
						
					}
					
				}
				
			}
			
		}
		
		class ChangeNameListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(fieldNewName.getText().equals("")) {
					
					JOptionPane.showMessageDialog(buttonChangeName, "Non � stato inserito nessun nome.", "Errore", JOptionPane.ERROR_MESSAGE);
					
				}
				else {
				
					multiplex.setName(fieldNewName.getText());
					JOptionPane.showMessageDialog(panel, "Nome Multisala Cambiato", "Successo", JOptionPane.INFORMATION_MESSAGE);
					
					labelMultiplexName.setText(multiplex.getName());
					
					FileManager.saveFile(multiplex);
					
				}
				
			}
			
		}
		
		buttonChangeName.addActionListener(new ChangeNameListener());	
		buttonAddHall.addActionListener(new AddHallListener());
		
		panel.setLayout(new GridLayout(8, 1));
		
		panel.add(panelName);
		panel.add(labelChangeName);
		panel.add(fieldNewName);
		panel.add(buttonChangeName);
		JPanel voidPanel = new JPanel();
		voidPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		panel.add(voidPanel);
		panel.add(labelSeatNumber);
		panel.add(fieldSeatNumber);
		panel.add(buttonAddHall);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		return panel;
		
	}	
	
	private JPanel createShowMultiplexPanel(Multiplex multiplex) {
		
		JPanel panel = new JPanel();
		JPanel panelMultiplexName = new JPanel();
		
		panel.setLayout(new GridLayout(3, 1));
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		JLabel labelMultiplexName = new JLabel("   " + multiplex.getName());
		labelMultiplexName.setFont(new Font("Arial", Font.BOLD, 18));
		labelMultiplexName.setForeground(Color.WHITE);
		panelMultiplexName.add(labelMultiplexName);
		panelMultiplexName.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		JLabel labelMultiplexHalls = new JLabel("Numero sale: " + multiplex.getArrayHalls().size());
		labelMultiplexHalls.setFont(new Font("Century SchoolBook", Font.BOLD, 14));
		labelMultiplexHalls.setForeground(Color.WHITE);
		
		JLabel labelMultiplexAccountNumber = new JLabel("Numero account creati: " + multiplex.getAccountList().size());
		labelMultiplexAccountNumber.setFont(new Font("Arial MT", Font.BOLD, 12));
		labelMultiplexAccountNumber.setForeground(Color.WHITE);
		
		panel.setLayout(new GridLayout(3, 1));
		
		panel.add(panelMultiplexName);
		panel.add(labelMultiplexHalls);
		panel.add(labelMultiplexAccountNumber);
		panel.setVisible(true);
		
		return panel;
		
	}
	
}
