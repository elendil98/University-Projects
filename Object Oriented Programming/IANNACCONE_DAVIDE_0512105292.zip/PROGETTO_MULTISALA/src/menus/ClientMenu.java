package menus;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import classes.Client;
import classes.Multiplex;

public class ClientMenu extends JMenu{

	private static final long serialVersionUID = 1L;

	public ClientMenu(Multiplex multiplex, JPanel mainPanel, Client client, JFrame frameChoice, JFrame frameClient) {

		class DeleteAccountListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				multiplex.removeAccount(multiplex.searchAccount(client.getUsername(), client.getPassword()));
				JOptionPane.showMessageDialog(mainPanel, "Account eliminato correttamente.", "Succeso", JOptionPane.INFORMATION_MESSAGE);
				
				if(multiplex.getArrayHalls().size() > 0) {
					
					for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
						
						for(int j = 0; j < multiplex.getArrayHalls().get(i).getShowArray().size(); j++) {
							
							multiplex.getArrayHalls().get(i).getShowArray().get(j).resetPrice();
							
						}
						
					}
					
					for(int k = 0; k < client.getBookingSeat().size(); k++) {
						client.getBookingSeat().get(k).setType(classes.Seat.Type.DISPONIBILE);
					}
					
				}
				
				frameChoice.setVisible(true);
				frameClient.dispose();
				
			}
			
		}
		
		class LogoutListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(multiplex.getArrayHalls().size() > 0) {
					
					for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
						
						for(int j = 0; j < multiplex.getArrayHalls().get(i).getShowArray().size(); j++) {
							
							multiplex.getArrayHalls().get(i).getShowArray().get(j).resetPrice();
							
						}
						
					}
					
					for(int k = 0; k < client.getBookingSeat().size(); k++) {
						client.getBookingSeat().get(k).setType(classes.Seat.Type.DISPONIBILE);
					}
					
				}
				
				
				frameChoice.setVisible(true);
				frameClient.dispose();
				
			}
			
		}
		
		this.setText("Menu");
		JMenuItem menuItemLogout;
		JMenuItem menuItemDeleteAccount;
		
		menuItemLogout = new JMenuItem("Logout");
		menuItemLogout.addActionListener(new LogoutListener());
		
		menuItemDeleteAccount = new JMenuItem("Elimina Account");
		menuItemDeleteAccount.addActionListener(new DeleteAccountListener());
		
		add(menuItemDeleteAccount);
		add(menuItemLogout);
		
		
	}
	
}
