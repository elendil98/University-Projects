package menus;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import classes.Multiplex;
import frames.FrameHallView;
import frames.FrameShowView;
import frames.FrameWeeklyProgram;
import tables.HallTable;

public class HallMenu extends JMenu{

	private static final long serialVersionUID = 1L;
	
	private JMenuItem menuItemViewHalls;
	
	public HallMenu(Multiplex multiplex, JPanel mainPanel) {
		
		class ViewHallsListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(multiplex.getArrayHalls().size() < 1) {
					
					JOptionPane.showMessageDialog(mainPanel, "Nessuna sala trovata nel multisala", "Errore", JOptionPane.ERROR_MESSAGE);
					
				}
				else {
					
					mainPanel.removeAll();
					mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
					JPanel hallPanel= new JPanel();
					HallTable hallTable = new HallTable(multiplex);
					mainPanel.add(hallTable);
					mainPanel.setBackground(Color.WHITE);
					
					hallPanel = createHallPanel(hallTable, multiplex, mainPanel);
					mainPanel.add(hallPanel);
						
					mainPanel.repaint();
					mainPanel.revalidate();
					
				}
				
			}
			
		}
		
		this.setText("Sale");
		
		menuItemViewHalls = new JMenuItem("Visualizza");
		menuItemViewHalls.addActionListener(new ViewHallsListener());
		
		
		
		add(menuItemViewHalls);
		
	}
	
	private JPanel createHallPanel(HallTable hallTable, Multiplex multiplex, JPanel mainPanel) {
		
		class ViewHallListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				int pos = hallTable.getHallTable().getSelectedRow();
				
				if(pos < 0) {
					JOptionPane.showMessageDialog(mainPanel, "Nessuna riga selezionata", "Errore", JOptionPane.ERROR_MESSAGE);
				}
				else {
						
					FrameHallView hallView = new FrameHallView(multiplex.getArrayHalls().get(pos));
					hallView.setAlwaysOnTop(true);
					
				}
				
			}
			
		}
		
		class ManageShowListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(hallTable.getShowTable().getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(mainPanel, "Nessuna riga selezionata", "Errore", JOptionPane.ERROR_MESSAGE);
				}
				else {
					
					for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
							
						int index = multiplex.getArrayHalls().get(i).searchShow(hallTable.getShowRowData()[hallTable.getShowTable().getSelectedRow()][6]);
							
						if(index != -1) {
				
							FrameShowView frameView = new FrameShowView(multiplex, i, index);
							frameView.setAlwaysOnTop(true);
							i = multiplex.getArrayHalls().size();
								
						}
			
					}
							
				}
				
			}
			
		}
		
		class WeeklyProgramListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(hallTable.getHallTable().getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(mainPanel, "Nessuna riga selezionata", "Errore", JOptionPane.ERROR_MESSAGE);
				}
				else {
					
					FrameWeeklyProgram weeklyView = new FrameWeeklyProgram(multiplex, multiplex.getArrayHalls().get(hallTable.getHallTable().getSelectedRow()));
					weeklyView.setAlwaysOnTop(true);
					
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		JButton viewHallButton = new JButton("Visualizza Sala");
		viewHallButton.addActionListener(new ViewHallListener());
		
		JButton manageShowButton = new JButton("Gestisci Spettacoli");
		manageShowButton.addActionListener(new ManageShowListener());
		manageShowButton.setVisible(false);
		
		JButton weeklyProgramButton = new JButton("Programmazione Settimanale");
		weeklyProgramButton.addActionListener(new WeeklyProgramListener());
		
		hallTable.addListener(viewHallButton, manageShowButton, weeklyProgramButton);
		
		panel.add(viewHallButton);
		panel.add(manageShowButton);
		panel.add(weeklyProgramButton);
		
		return panel;
		
	}

}
