package menus;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import classes.Client;
import classes.Multiplex;
import frames.FrameBookingView;
import tables.ShowTable;

public class WeeklyProgramMenu extends JMenu{

	private static final long serialVersionUID = 1L;

	JMenuItem menuItemViewShow;
	Client client;
	
	public WeeklyProgramMenu(Multiplex multiplex, JPanel mainPanel, Client client) {
		
		this.client = client;
		
		class ViewShowListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(multiplex.getArrayHalls().size() < 1) {
					
					JOptionPane.showMessageDialog(mainPanel, "Nessuna sala trovata nel multisala", "Errore", JOptionPane.ERROR_MESSAGE);
					
				}
				else {
					
					mainPanel.removeAll();
					mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
					JPanel showPanel= new JPanel();
					ShowTable showTable = new ShowTable(multiplex, client);
					mainPanel.add(showTable);
					mainPanel.setBackground(Color.WHITE);
					
					showPanel = createShowPanel(showTable, multiplex, mainPanel);
					mainPanel.add(showPanel);
						
					mainPanel.repaint();
					mainPanel.revalidate();
					
				}
				
			}
			
		}
		
		
		this.setText("Programmazione");
		
		menuItemViewShow = new JMenuItem("Visualizza");
		menuItemViewShow.addActionListener(new ViewShowListener());		
		
		add(menuItemViewShow);
		
	}
	
	private JPanel createShowPanel(ShowTable showTable, Multiplex multiplex, JPanel mainPanel) {
		
		class ConfirmBookingListener implements ActionListener {
		
			public void actionPerformed(ActionEvent event) {
				
				double total = 0;
				
				for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
					
					for(int j = 0; j < multiplex.getArrayHalls().get(i).getShowArray().size(); j++) {
						
						total += multiplex.getArrayHalls().get(i).getShowArray().get(j).getPrice();
						multiplex.getArrayHalls().get(i).getShowArray().get(j).resetPrice();
						
					}
					
				}
				
				if(client.getBankAccount().getBalance() >= total) {
					multiplex.addEntry(total);
					client.getBankAccount().withdraw(total);
					client.resetBookingSeat();
				}
				
			}
			
		}
		
		class ManageShowListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(showTable.getAvailableShowTable().getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(mainPanel, "Nessuna riga selezionata", "Errore", JOptionPane.ERROR_MESSAGE);
				}
				else {
					
					for(int i = 0; i < multiplex.getArrayHalls().size(); i++) {
						
						int index = multiplex.getArrayHalls().get(i).searchShow(showTable.getAvailableShowRowData()[showTable.getAvailableShowTable().getSelectedRow()][6]);
							
						if(index != -1) {
							
							FrameBookingView frameView = new FrameBookingView(multiplex, i, index, client);
							frameView.setAlwaysOnTop(true);
							i = multiplex.getArrayHalls().size();
							
						}
						
					}
					
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		JButton bookingButton = new JButton("Effettua Prenotazione");
		bookingButton.addActionListener(new ManageShowListener());
		
		JButton bookingConfirmButton = new JButton("Conferma Prenotazione");
		bookingConfirmButton.addActionListener(new ConfirmBookingListener());
		
		showTable.addListener(panel);
		
		panel.add(bookingButton);
		panel.add(bookingConfirmButton);
		
		panel.setVisible(false);
		return panel;
		
	}

	
}
