package menus;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import classes.FileManager;
import classes.Manager;
import classes.Multiplex;
import tables.AccountTable;

public class AccountMenu extends JMenu{

	private static final long serialVersionUID = 1L;
	
	public AccountMenu(Multiplex multiplex, JPanel mainPanel, Manager manager, JFrame frameChoice, JFrame frameManager) {
		
		class DeleteAccountListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				multiplex.removeAccount(multiplex.searchAccount(manager.getUsername(), manager.getPassword()));
				JOptionPane.showMessageDialog(mainPanel, "Account eliminato correttamente.", "Succeso", JOptionPane.INFORMATION_MESSAGE);
				frameChoice.setVisible(true);
				frameManager.dispose();
				
			}
			
		}
		
		class LogoutListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				frameChoice.setVisible(true);
				frameManager.dispose();
				
			}
			
		}
		
		class ChangeCredentialsListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				mainPanel.removeAll();
				mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
				JPanel changeCredentialsPanel= new JPanel();
				AccountTable accountTable = new AccountTable(multiplex);
				mainPanel.add(accountTable);
				mainPanel.setBackground(Color.WHITE);
				
				changeCredentialsPanel = createCredentialsPanel(accountTable, multiplex, mainPanel);
				mainPanel.add(changeCredentialsPanel);
					
				mainPanel.repaint();
				mainPanel.revalidate();
				
			}
			
		}
		
		this.setText("Menu");
		JMenuItem menuItemLogout;
		JMenuItem menuItemCredentials;
		JMenuItem menuItemDeleteAccount;
		
		menuItemCredentials = new JMenuItem("Account");
		menuItemCredentials.addActionListener(new ChangeCredentialsListener());
		
		menuItemLogout = new JMenuItem("Logout");
		menuItemLogout.addActionListener(new LogoutListener());
		
		menuItemDeleteAccount = new JMenuItem("Elimina Account");
		menuItemDeleteAccount.addActionListener(new DeleteAccountListener());
		
		add(menuItemCredentials);
		add(menuItemDeleteAccount);
		add(menuItemLogout);
		
	}

	public JPanel createCredentialsPanel(AccountTable accountTable, Multiplex multiplex, JPanel mainPanel) {
		
		class ChangeListener implements ActionListener {
			
			private int index;
			private final String text;
			private final String titleText;
			
			public ChangeListener(int index, String text, String titleText) {
				
				this.index = index;
				this.text = text;
				this.titleText = titleText;
		
			}
			
			public void actionPerformed(ActionEvent event) {
				
				if(accountTable.getManagerTable().getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(mainPanel, "Nessuna riga selezionata", "Errore", JOptionPane.ERROR_MESSAGE);
				}
				else {
					
					String changeCredentials = JOptionPane.showInputDialog(mainPanel, text, titleText, JOptionPane.QUESTION_MESSAGE);	
					int indexAccount = multiplex.searchAccountIndex(accountTable.getManagerRowData()[accountTable.getManagerTable().getSelectedRow()][0], accountTable.getManagerRowData()[accountTable.getManagerTable().getSelectedRow()][1]);
					multiplex.getAccountList().get(indexAccount).setCredentials(changeCredentials, index);
					FileManager.saveFile(multiplex);
					accountTable.getManagerRowData()[accountTable.getManagerTable().getSelectedRow()][index] = "" + changeCredentials;
					accountTable.getManagerTable().repaint();
					
				}
		
			}	
			
		}
		
		JPanel panel = new JPanel();

		JButton changeUsernameButton = new JButton("Cambia Username");
		JButton changePasswordButton = new JButton("Cambia Password");
		
		changeUsernameButton.addActionListener(new ChangeListener(0, "Inserisci nuovo username:", "Cambia Username"));
		changePasswordButton.addActionListener(new ChangeListener(1, "Inserisci nuova password:", "Cambia Password"));
		accountTable.addListener(panel);
		
		panel.setLayout(new GridLayout(1, 2));
		panel.add(changeUsernameButton);
		panel.add(changePasswordButton);
		
		return panel;
		
	}
	
	
}
