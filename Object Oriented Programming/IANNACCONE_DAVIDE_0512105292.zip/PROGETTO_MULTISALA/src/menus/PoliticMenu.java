package menus;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import classes.Multiplex;
import exception.NoPoliticException;

public class PoliticMenu extends JMenu{

	private static final long serialVersionUID = 1L;

	private JMenuItem menuItemPolitic;
	private JPanel politicPanel;
	private JComboBox<String> politicBox;
	private JTextArea areaPolitic;
	private JButton buttonEnable;
	private JButton buttonDisable;
	
	public PoliticMenu(Multiplex multiplex, JPanel mainPanel) {
		
		class ShowPoliticListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				mainPanel.removeAll();
				mainPanel.revalidate();
				mainPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
				politicPanel = createPoliticPanel(multiplex);
				
				mainPanel.setLayout(new GridBagLayout());
				mainPanel.add(politicPanel);
				mainPanel.repaint();
				
			}
			
		}
		
		this.setText("Politiche");
		
		menuItemPolitic = new JMenuItem("Gestisci");
		menuItemPolitic.addActionListener(new ShowPoliticListener());
		
		add(menuItemPolitic);
		
	}
	
	private JPanel createPoliticPanel(Multiplex multiplex) {
		
		JPanel panel = new JPanel();
		
		class EnablePoliticListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(multiplex.getPoliticsList().get(politicBox.getSelectedIndex()).isActive()) {
					JOptionPane.showMessageDialog(panel, "Politica gi� attiva", "Attenzione", JOptionPane.INFORMATION_MESSAGE);
				}
				else {
					
					multiplex.getPoliticsList().get(politicBox.getSelectedIndex()).setActive(true);
					areaPolitic.append("Attivata politica: " + multiplex.getPoliticsList().get(politicBox.getSelectedIndex()).getName() + "\n");
					buttonEnable.setBackground(Color.GREEN);
					buttonDisable.setBackground(Color.BLUE);
					
				}
				
			}
			
			
		}
		
		class DisablePoliticListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {

				if(multiplex.getPoliticsList().get(politicBox.getSelectedIndex()).isActive()) {
					
					multiplex.getPoliticsList().get(politicBox.getSelectedIndex()).setActive(false);
					areaPolitic.append("Disattivata politica: " + multiplex.getPoliticsList().get(politicBox.getSelectedIndex()).getName() + "\n");	
					buttonEnable.setBackground(Color.BLUE);
					buttonDisable.setBackground(Color.GREEN);
				
				}
				else {
					JOptionPane.showMessageDialog(panel, "Politica gi� disattivata", "Attenzione", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
			
		}
		
		class ChangePoliticListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(multiplex.getPoliticsList().get(politicBox.getSelectedIndex()).isActive()) {
					buttonEnable.setBackground(Color.GREEN);
					buttonDisable.setBackground(Color.BLUE);
				}
				else {
					buttonEnable.setBackground(Color.BLUE);
					buttonDisable.setBackground(Color.GREEN);
				}
				
				
			}
			
			
		}
		
		panel.setLayout(new GridLayout(2, 1));
		
		areaPolitic = new JTextArea(10, 20);
		areaPolitic.setBackground(Color.GRAY);
		areaPolitic.setFont(new Font("Arial", Font.BOLD, 10));
		areaPolitic.setForeground(Color.WHITE);
		areaPolitic.setEditable(false);
		
		JScrollPane areaPane = new JScrollPane(areaPolitic);
		areaPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		areaPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		buttonEnable = new JButton("Attiva");
		buttonEnable.addActionListener(new EnablePoliticListener());
		
		buttonDisable = new JButton("Disattiva");
		buttonDisable.addActionListener(new DisablePoliticListener());
		
		try {
			
			String[] politicName = new String[multiplex.getPoliticsList().size()];
			
			for(int i = 0; i < multiplex.getPoliticsList().size(); i++) {
				
				politicName[i] = multiplex.getPoliticsList().get(i).getName();
				
			}
			
			politicBox = new JComboBox<String>(politicName);
			
			if(multiplex.getPoliticsList().get(0).isActive()) {
				
				buttonEnable.setBackground(Color.BLUE);
				buttonDisable.setBackground(Color.GREEN);
				
			}
			else {
				
				buttonEnable.setBackground(Color.GREEN);
				buttonDisable.setBackground(Color.BLUE);
				
			}
			
		}
		catch(NoPoliticException e) {
			e.printStackTrace();
		}
		
		politicBox.addActionListener(new ChangePoliticListener());
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(3, 1));
		buttonPanel.add(politicBox);
		buttonPanel.add(buttonEnable);
		buttonPanel.add(buttonDisable);

		
		panel.add(areaPane);
		panel.add(buttonPanel);
		
		return panel;

	}
	
}
