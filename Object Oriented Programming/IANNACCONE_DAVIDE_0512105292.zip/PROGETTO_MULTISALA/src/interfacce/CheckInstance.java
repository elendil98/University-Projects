package interfacce;

public interface CheckInstance {

	/**
	 * check the account type (Manager or Client), true for Manager
	 * @return true/false
	 */
	
	public boolean checkAccountType();
	
}
