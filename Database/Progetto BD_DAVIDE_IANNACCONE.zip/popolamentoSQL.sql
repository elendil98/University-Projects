use dbelettronica;

/* Popolo la tabella dei negozi */
insert into Negozio (nome, indirizzo) values ('Mediaworld Pife','Via Lipi 12');
insert into Negozio (nome, indirizzo) values ('Mediaworld Lefi','Via Cic 15');

/* Popolo la tabella dei depositi */
insert into Deposito (codice_negozio) values (1);
insert into Deposito (codice_negozio) values (2);

/* Popolo la tabella dei reparti */
insert into Reparto (nome_reparto, ID_Negozio) values ('Elettrodomestici', 1);
insert into Reparto (nome_reparto, ID_Negozio) values ('Telefonia', 1);
insert into Reparto (nome_reparto, ID_Negozio) values ('Videogiochi', 1);
insert into Reparto (nome_reparto, ID_Negozio) values ('Tv/Monitor', 1);
insert into Reparto (nome_reparto, ID_Negozio) values ('Computer', 1);

insert into Reparto (nome_reparto, ID_Negozio) values ('Elettrodomestici', 2);
insert into Reparto (nome_reparto, ID_Negozio) values ('Telefonia', 2);
insert into Reparto (nome_reparto, ID_Negozio) values ('Videogiochi', 2);
insert into Reparto (nome_reparto, ID_Negozio) values ('Tv/Monitor', 2);
insert into Reparto (nome_reparto, ID_Negozio) values ('Computer', 2);

/* Popolo la tabella delle marche */
insert into Marca (nome, logo, azienda) values ('Apple', 'mela', 'Cupertino, CA');
insert into Marca (nome, logo, azienda) values ('Microsoft', 'rettangoli', 'Cupertino, CA');
insert into Marca (nome, logo, azienda) values ('Huawei', 'UAU', 'EI');
insert into Marca (nome, logo, azienda) values ('Xiaomi','SCIA','OMI');

/* Popolo la tabella degli impiegati */
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Federico', 'Allegretti', 1200.00, 2);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Giovanni', 'De Giorgio', 1500.00, 2);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Davide', 'Iannaccone', 600.00, 1);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Domenico', 'Esposito', 1200.00, 2);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Antonello', 'Luppolo', 30.00, 2);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Federico', 'Siano', 1200.00, 2);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Francesco', 'Spirito', 1200.00, 1);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Francesco', 'Migliaro', 600.00, 1);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Francesco', 'Falleti', 1200.00, 1);
insert into Impiegato (nome, cognome, stipendio, id_negozio) values ('Antonio', 'Lodato', 30.00, 1);

/* Aggiungo 2 supervisori. Uno per negozio */
insert into Supervisore (codice_impiegato) values (1); /* Federico Allegretti */
insert into Supervisore (codice_impiegato) values (3); /* Davide Iannaccone */

/* Aggiungo la relazione */
insert into Supervisiona (codice_impiegato, codice_supervisore) values (2, 1);
insert into Supervisiona (codice_impiegato, codice_supervisore) values (4, 1);
insert into Supervisiona (codice_impiegato, codice_supervisore) values (5, 1);
insert into Supervisiona (codice_impiegato, codice_supervisore) values (6, 1);

insert into Supervisiona (codice_impiegato, codice_supervisore) values (7, 2);
insert into Supervisiona (codice_impiegato, codice_supervisore) values (8, 2);
insert into Supervisiona (codice_impiegato, codice_supervisore) values (9, 2);
insert into Supervisiona (codice_impiegato, codice_supervisore) values (10, 2);

/* Popolo le tabelle Magazziniere, Addetto Vendita, Commesso */
insert into Commesso (codice_impiegato) values (3);
insert into Commesso (codice_impiegato) values (4);
insert into Magazziniere (codice_impiegato, codice_deposito) values (5, 1);
insert into Addetto_Vendita (codice_impiegato, codice_reparto) values (6, 2);

insert into Commesso (codice_impiegato) values (7);
insert into Commesso (codice_impiegato) values (8);
insert into Magazziniere (codice_impiegato, codice_deposito) values (9, 2);
insert into Addetto_Vendita (codice_impiegato, codice_reparto) values (10, 8);

/* Popolo la tabella dei clienti */
insert into Cliente (codice_fiscale, nome, cognome, tessera) values ('MRTDTR06P25F839A', 'DIMITRI', 'MARTINO', 0);
insert into Cliente (codice_fiscale, nome, cognome, tessera) values ('STFLNE05M46A944A','ELENIA','STEFANI',0);
insert into Cliente (codice_fiscale, nome, cognome, tessera) values ('VNTDRS05S57A944K','DOLORES','VENTURINI',0);
insert into Cliente (codice_fiscale, nome, cognome, tessera) values ('MGLMHL05T06D969Y','MICHELANGELO','MIGLIORE',0);
insert into Cliente (codice_fiscale, nome, cognome, tessera) values ('CRTLYL04P48L736D','LAYLA','CORTESE',0);

/* Popolo la tabella è frequentato */
insert into E_Frequentato (id_negozio, codice_cliente) values (1, 'MRTDTR06P25F839A');
insert into E_Frequentato (id_negozio, codice_cliente) values (1, 'STFLNE05M46A944A');
insert into E_Frequentato (id_negozio, codice_cliente) values (1, 'VNTDRS05S57A944K');
insert into E_Frequentato (id_negozio, codice_cliente) values (2, 'MGLMHL05T06D969Y');
insert into E_Frequentato (id_negozio, codice_cliente) values (2, 'CRTLYL04P48L736D');

/* Popolo la tabella delle tessere */
insert into Tessera (punti, data_rilascio, codice_cliente) values (200, '2019-01-23', 'CRTLYL04P48L736D');
insert into Tessera (punti, data_rilascio, codice_cliente) values (100, '2019-01-18', 'MGLMHL05T06D969Y');
insert into Tessera (punti, data_rilascio, codice_cliente) values (50, '2019-02-28', 'VNTDRS05S57A944K');

/* Popolo la tabella delle partite iva */
insert into Partita_IVA (numero, codice_cliente) values ('10275640912', 'MRTDTR06P25F839A');
insert into Partita_IVA (numero, codice_cliente) values ('19365926481', 'VNTDRS05S57A944K');
insert into Partita_IVA (numero, codice_cliente) values ('17462964832', 'CRTLYL04P48L736D');

/* Popolo la tabella Fornitore */
insert into Fornitore (partita_iva, nome, indirizzo) values ('12345678912', 'Giovanni', 'Via Broundi 23');
insert into Fornitore (partita_iva, nome, indirizzo) values ('12345678913', 'Peppe', 'Via Dirso 16');

/* Popolo la tabella ordine */
insert into Ordine (saldo_ordine, data_ordine, codice_supervisore) values (1000.00, '2018-10-20', 1);
insert into Ordine (saldo_ordine, data_ordine, codice_supervisore) values (1500.00, '2018-07-12', 1);
insert into Ordine (saldo_ordine, data_ordine, codice_supervisore) values (3000.00, '2018-12-12', 2);

/* Popolo la tabella provvede */
insert into Provvede (codice_ordine, partita_iva_fornitore) value (1, '12345678912');
insert into Provvede (codice_ordine, partita_iva_fornitore) value (2, '12345678912');
insert into Provvede (codice_ordine, partita_iva_fornitore) value (3, '12345678913');

/* Popolo la tabella dei recapiti */
insert into Recapito (numero) value ('3314525095'); /* Impiegato */
insert into E_Fornito_Imp (numero_recapito, codice_impiegato) values ('3314525095', 1);
insert into Recapito (numero) value ('7195921544'); /* Fornitore */
insert into E_Fornito_Forn (numero_recapito, partita_iva_fornitore) values ('7195921544', '12345678912');
insert into Recapito (numero) value ('5026947474'); /* Cliente */
insert into E_Fornito_Cl (numero_recapito, codice_fiscale_cliente) values ('5026947474', 'MRTDTR06P25F839A');

/* Popolo la tabella degli sconti */
insert into Sconto (nome, percentuale) values ('Nuova Apertura', 20);

/* Popolo la tabella dei prodotti */
insert into Prodotto (nome, quantità, iva, nome_marca) values ('Macbook', 100, 20, 'Apple');
insert into Prodotto (nome, quantità, iva, nome_marca) values ('Ipad Pro', 100, 20, 'Apple');
insert into Prodotto (nome, quantità, iva, nome_marca) values ('iMac', 100, 20, 'Apple');
insert into Prodotto (nome, quantità, iva, nome_marca) values ('Matebook X', 100, 20, 'Huawei');
insert into Prodotto (nome, quantità, iva, nome_marca) values ('RedMi Note 10', 100, 20, 'Xiaomi');

insert into Disponibile (codice_prodotto, prezzo, codice_reparto) values (1, 1200.00, 5);
insert into Disponibile (codice_prodotto, prezzo, codice_reparto) values (2, 900.00, 5);
insert into Disponibile (codice_prodotto, prezzo, inizio_offerta, fine_offerta, nome_sconto, codice_reparto) values (5, 300.00, '2019-01-20', '2019-03-30', 'Nuova Apertura', 7);

/* Popolo la tabella immagazzinato */
insert into Immagazzinato (codice_prodotto, codice_deposito) values (1, 1);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (2, 1);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (3, 1);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (4, 1);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (5, 1);

insert into Immagazzinato (codice_prodotto, codice_deposito) values (1, 2);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (2, 2);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (3, 2);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (4, 2);
insert into Immagazzinato (codice_prodotto, codice_deposito) values (5, 2);

/* Popolo la tabella delle ricevute */
insert into Ricevuta (metodo_di_pagamento, fattura, codice_commesso, codice_cliente, codice_tessera) values ('Banconote', 0, 3, 'MRTDTR06P25F839A', null);
insert into Ricevuta (metodo_di_pagamento, fattura, codice_commesso, codice_cliente, codice_tessera) values ('Carta di credito', 0, 4, 'MGLMHL05T06D969Y', null);
insert into Ricevuta (metodo_di_pagamento, fattura, codice_commesso, codice_cliente, codice_tessera) values ('Prepagata', 0, 8, 'CRTLYL04P48L736D', 1);

/* Popolo la tabella si compone di */
insert into Si_Compone_Di (codice_ricevuta, codice_prodotto) values (1, 1);
insert into Si_Compone_Di (codice_ricevuta, codice_prodotto) values (2, 2);
insert into Si_Compone_Di (codice_ricevuta, codice_prodotto) values (3, 5);

/* Popolo la tabella composto da */
insert into Composto_Da (codice_ordine, codice_prodotto) values (1, 1);
insert into Composto_Da (codice_ordine, codice_prodotto) values (1, 2);
insert into Composto_Da (codice_ordine, codice_prodotto) values (2, 4);
insert into Composto_Da (codice_ordine, codice_prodotto) values (3, 3);
insert into Composto_Da (codice_ordine, codice_prodotto) values (3, 5);

/* QUERY PER LA SELECT */
-- select * from Si_Compone_Di;
-- select * from Composto_Da;
-- select * from Sconto;
-- select * from Immagazzinato;
-- select * from Prodotto;
-- select * from Disponibile;
-- select * from Composto_Da;
-- select * from E_Frequentato;
-- select * from ordine where ordine.codice_supervisore = 1;
-- select * from Provvede;
-- select * from Tessera;
-- select * from Ricevuta;
-- select * from Partita_IVA;
-- select * from Impiegato;
-- select * from Deposito;
-- select * from Fornitore;
-- select * from E_Fornito_Imp;
-- select * from E_Fornito_Forn;
-- select * from E_Fornito_Cl;
-- select * from Cliente;
-- select * from Supervisore;
-- select * from reparto;
-- select * from negozio;
-- select * from Supervisiona;
-- select * from Commesso;
-- select * from Magazziniere;
-- select * from Addetto_Vendita;
-- select I1.nome, I1.cognome, I1.codice 
-- from Impiegato as I1, Supervisiona
-- where I1.Codice = Supervisiona.codice_impiegato union ( select I2.nome, I2.cognome, I2.codice
-- 																from impiegato as I2, supervisore
--                                                                 where I2.codice = supervisore.codice_impiegato)
-- order by codice asc;

