drop database if exists dbelettronica;
create database dbelettronica;
use dbelettronica;

/* TABLE: Negozio */
drop table if exists Negozio;
create table Negozio (
	ID smallint unsigned not null auto_increment,
    Nome varchar(20),
    Indirizzo varchar(50) not null,
    primary key(ID, nome));

/* TABLE: Reparto */    
drop table if exists Reparto;
create table Reparto (
	Codice smallint unsigned not null auto_increment,
    Nome_Reparto varchar(25),
    ID_Negozio smallint unsigned,
    primary key(Codice),
    foreign key(ID_Negozio) references Negozio(ID) on delete cascade);
    
/* TABLE: Deposito */
drop table if exists Deposito;
create table Deposito (
	Codice_Negozio smallint unsigned,
    primary key(Codice_Negozio),
    foreign key(Codice_Negozio) references Negozio (ID) on delete cascade);

/* TABLE: Recapito */
drop table if exists Recapito;
create table Recapito (
	Numero varchar(10) not null,
    primary key(Numero));

/* TABLE: Impiegato */
drop table if exists Impiegato;
create table Impiegato (
	Codice smallint unsigned unique not null auto_increment,
    Nome varchar(20),
    Cognome varchar(30),
    Stipendio float,
    ID_Negozio smallint unsigned,
    primary key(Codice),
    foreign key(ID_Negozio) references Negozio (ID) on delete cascade);

/* TABLE: Supervisore */
drop table if exists Supervisore;
create table Supervisore (
	Codice smallint unsigned unique not null auto_increment,
    Codice_Impiegato smallint unsigned,
    primary key(Codice_Impiegato, Codice),
    foreign key(Codice_Impiegato) references Impiegato (Codice) on delete cascade);
    
/* TABLE: Supervisiona*/
drop table if exists Supervisiona;
create table Supervisiona (
	Codice_Impiegato smallint unsigned,
    Codice_Supervisore smallint unsigned,
    primary key(Codice_impiegato, Codice_Supervisore),
    foreign key(Codice_Impiegato) references Impiegato (Codice) on delete cascade,
    foreign key(Codice_Supervisore) references Supervisore (Codice) on delete cascade);
    
/* TABLE: Magazziniere */   
drop table if exists Magazziniere;
create table Magazziniere (
	Codice_Impiegato smallint unsigned unique,
	Codice_Deposito smallint unsigned unique,
    primary key(Codice_Impiegato),
	foreign key(Codice_Impiegato) references Impiegato (Codice) on delete cascade,
	foreign key(Codice_Deposito) references Deposito (Codice_Negozio));
	
/* TABLE: Addetto Vendita */
drop table if exists Addetto_Vendita; 
create table Addetto_Vendita (
	Codice_Impiegato smallint unsigned,
    Codice_Reparto smallint unsigned,
    primary key(Codice_Impiegato),
    foreign key(Codice_Impiegato) references Impiegato (Codice) on delete cascade,
    foreign key(Codice_Reparto) references Reparto (Codice));

/* TABLE: Commesso */
drop table if exists Commesso;
create table Commesso (
	Codice_Impiegato smallint unsigned,
    primary key(Codice_Impiegato),
    foreign key(Codice_Impiegato) references Impiegato(Codice) on delete cascade);
    
/* TABLE: Ordine */
drop table if exists Ordine;
create table Ordine (
	Codice smallint unsigned not null auto_increment,
    Saldo_Ordine float,
    Data_Ordine date,
    Codice_Supervisore smallint unsigned,
    primary key(Codice),
    foreign key(Codice_Supervisore) references Supervisore (Codice));

/* TABLE: Marca */
drop table if exists Marca;
create table Marca (
	Nome varchar(30) not null,
    Logo varchar(15),
    Azienda varchar(30),
    primary key(Nome));
    
/* TABLE: Sconto */
drop table if exists Sconto;
create table Sconto (
	Nome varchar(20) not null,
    Percentuale int,
    primary key (Nome));

/* TABLE: Prodotto */
drop table if exists Prodotto;
create table Prodotto (
	Codice smallint unsigned not null auto_increment,
    Nome varchar(20) unique,
    Quantità int,
    IVA int,
    Nome_Marca varchar(30),
    primary key(Codice),
    foreign key(Nome_Marca) references Marca (Nome));

/* TABLE: Disponibile */
drop table if exists Disponibile;
create table Disponibile (
	Codice_Prodotto smallint unsigned,
    Prezzo float,
    Inizio_Offerta date,
    Fine_Offerta date,
    Nome_Sconto varchar(20),
    Codice_Reparto smallint unsigned,
    primary key(Codice_Prodotto),
    foreign key(Codice_Prodotto) references Prodotto (Codice) on delete cascade,
    foreign key(Nome_Sconto) references Sconto (Nome),
    foreign key(Codice_Reparto) references Reparto (Codice));

/* TABLE: Immagazzinato */
drop table if exists Immagazzinato;
create table Immagazzinato (
	Codice_Prodotto smallint unsigned,
    Codice_Deposito smallint unsigned,
    primary key(Codice_Prodotto, Codice_Deposito),
    foreign key(Codice_Prodotto) references Prodotto (Codice) on delete cascade,
    foreign key(Codice_Deposito) references Negozio (ID) on delete cascade);

/* TABLE: Fornitore */
drop table if exists Fornitore;
create table Fornitore (
	Partita_IVA varchar(11) not null,
    Nome varchar(20),
    Indirizzo varchar(50),
    primary key(Partita_IVA));
    
/* TABLE: Provvede */
drop table if exists Provvede;
create table Provvede (
	Codice_Ordine smallint unsigned,
    Partita_IVA_Fornitore varchar(11) not null,
    primary key(Codice_Ordine, Partita_IVA_Fornitore),
    foreign key(Codice_Ordine) references Ordine (Codice) on delete cascade,
    foreign key(Partita_IVA_Fornitore) references Fornitore (Partita_IVA));

/* TABLE: Tessera */
drop table if exists Tessera;
create table Tessera (
	Codice smallint unsigned not null auto_increment,
    Punti int,
    Data_Rilascio date,
    Codice_Cliente varchar(16) not null unique,
    primary key(Codice));

/* TABLE: Ricevuta */
drop table if exists Ricevuta;
create table Ricevuta (
	Codice smallint unsigned not null auto_increment,
    Metodo_di_Pagamento varchar(30),
    Fattura boolean,
    Codice_Commesso smallint unsigned,
    Codice_Cliente varchar(16) not null,
    Codice_Tessera smallint unsigned,
    primary key(Codice),
    foreign key(Codice_Commesso) references Commesso (Codice_Impiegato),
    foreign key(Codice_Tessera) references Tessera (Codice));

/* TABLE: Cliente */
drop table if exists Cliente;
create table Cliente (
	Codice_Fiscale varchar(16) not null,
    Nome varchar(20),
    Cognome varchar(25),
    Tessera boolean,
    primary key(Codice_Fiscale));
    
/* Aggiungo la chiave esterna del cliente alla Ricevuta */
alter table Ricevuta add foreign key(Codice_Cliente) references Cliente (Codice_Fiscale) on delete cascade;
/* Aggiungo la chiave esterna del cliente alla Tessera */
alter table Tessera add foreign key(Codice_Cliente) references Cliente (Codice_Fiscale) on delete cascade;

/* TABLE: E' Frequentato */
drop table if exists E_Frequentato;
create table E_Frequentato (
	ID_Negozio smallint unsigned,
    Codice_Cliente varchar(16) not null,
    primary key(ID_Negozio, Codice_Cliente),
    foreign key(ID_Negozio) references Negozio (ID) on delete cascade,
    foreign key(Codice_Cliente) references Cliente (Codice_Fiscale) on delete cascade);
    
/* TABLE: Si Compone Di */
drop table if exists Si_Compone_Di;
create table Si_Compone_Di (
	Codice_Ricevuta smallint unsigned,
    Codice_Prodotto smallint unsigned,
    primary key(Codice_Ricevuta, Codice_Prodotto),
    foreign key(Codice_Ricevuta) references Ricevuta (Codice) on delete cascade,
    foreign key(Codice_Prodotto) references Prodotto (Codice) on delete cascade);
    
/* TABLE: Composto Da */
drop table if exists Composto_Da;
create table Composto_Da (
	Codice_Ordine smallint unsigned not null,
    Codice_Prodotto smallint unsigned not null,
    primary key(Codice_Ordine, Codice_Prodotto),
    foreign key(Codice_Ordine) references Ordine (Codice) on delete cascade,
    foreign key(Codice_Prodotto) references Prodotto (Codice) on delete cascade);
    
/* TABLE: Partita IVA */
drop table if exists Partita_IVA;
create table Partita_IVA (
	Numero varchar(11) not null,
    Codice_Cliente varchar(16) not null unique,
    primary key(Numero),
    foreign key(Codice_Cliente) references Cliente (Codice_Fiscale) on delete cascade);
    
/* TABLE: E_Fornito_Imp */
drop table if exists E_Fornito_Imp;
create table E_Fornito_Imp (
	Numero_Recapito varchar(10) not null unique,
    Codice_Impiegato smallint unsigned not null,
    primary key(Numero_Recapito, Codice_Impiegato),
    foreign key(Numero_Recapito) references Recapito (Numero) on delete cascade,
    foreign key(Codice_Impiegato) references Impiegato (Codice) on delete cascade);

/* TABLE: E_Fornito_Forn */
drop table if exists E_Fornito_Forn;
create table E_Fornito_Forn (
	Numero_Recapito varchar(10) not null unique,
    Partita_IVA_Fornitore varchar(11) not null,
    primary key(Numero_Recapito, Partita_IVA_Fornitore),
    foreign key(Numero_Recapito) references Recapito (Numero) on delete cascade,
    foreign key(Partita_IVA_Fornitore) references Fornitore (Partita_IVA) on delete cascade);
    
/* TABLE: E_Fornito_Cl */
drop table if exists E_Fornito_Cl;
create table E_Fornito_Cl (
	Numero_Recapito varchar(11) not null unique,
    Codice_Fiscale_Cliente varchar(16) not null,
    primary key(Numero_Recapito, Codice_Fiscale_Cliente),
    foreign key(Numero_Recapito) references Recapito (Numero) on delete cascade,
    foreign key(Codice_Fiscale_Cliente) references Cliente (Codice_Fiscale) on delete cascade);