package starter;

import javax.swing.JFrame;

import frames.FrameWelcome;

public class Starter {

	public static void main(String[] args) {
	
		JFrame startFrame = new FrameWelcome();
		
		startFrame.setVisible(true);

	}

}
