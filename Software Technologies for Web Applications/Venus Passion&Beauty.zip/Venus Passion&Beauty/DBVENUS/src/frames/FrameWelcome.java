package frames;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FrameWelcome extends JFrame{

	private static final long serialVersionUID = 1L;

	JPanel panelMain;
	JPanel panelButton;
	JPanel panelLabel;
	JLabel labelWelcome;
	JButton buttonInsertClient;
	JButton buttonInsertEsthetic;
	JButton buttonInsertMachine;
	JButton buttonInsertProduct;
	JButton buttonInsertDate;
	
	public FrameWelcome() {
		
		panelMain = new JPanel();
		panelButton = createButtonPanel();
		panelLabel = createLabelPanel();
		
		panelMain.setLayout(new GridLayout(2, 1));
		panelMain.add(panelLabel);
		panelMain.add(panelButton);
		
		add(panelMain);		
		panelMain.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		pack();
		setTitle("Venus Passion&Beauty");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	private JPanel createLabelPanel() {
		
		JPanel panel = new JPanel();
		
		labelWelcome = new JLabel("Benvenuto nel Database Venus Passion&Beauty");
		labelWelcome.setForeground(new Color(1.0F, 0.8F, 0.8F));
		
		panel.add(labelWelcome);
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		return panel;
		
	}
	
	private JPanel createButtonPanel() {
		
		class InsertClientListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				FrameClient frameClient = new FrameClient(FrameWelcome.this);
				frameClient.setVisible(true);
				setVisible(false);
				
			}
		
		}
		
		class InsertEstheticListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				FrameEsthetic frameEsthetic = new FrameEsthetic(FrameWelcome.this);
				frameEsthetic.setVisible(true);
				setVisible(false);
				
			}
			
		}
		
		class InsertDateListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				FrameDate frameDate = new FrameDate(FrameWelcome.this);
				frameDate.setVisible(true);
				setVisible(false);
				
			}
			
		}
		
		class InsertMachineListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				FrameMachine frameMachine = new FrameMachine(FrameWelcome.this);
				frameMachine.setVisible(true);
				setVisible(false);
				
			}
				
		}
		
		class InsertProductListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				FrameProduct frameProduct = new FrameProduct(FrameWelcome.this);
				frameProduct.setVisible(true);
				setVisible(false);
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		buttonInsertClient = new JButton("Inserisci Clienti");
		ActionListener listenerClient = new InsertClientListener();
		buttonInsertClient.addActionListener(listenerClient);
		
		buttonInsertDate = new JButton("Inserisci Apputamento");
		ActionListener listenerDate = new InsertDateListener();
		buttonInsertDate.addActionListener(listenerDate);
		
		buttonInsertEsthetic = new JButton("Inserisci Estetista");
		ActionListener listenerEsthetic = new InsertEstheticListener();
		buttonInsertEsthetic.addActionListener(listenerEsthetic);
		
		buttonInsertMachine = new JButton("Inserisci Macchinario");
		ActionListener listenerMachine = new InsertMachineListener();
		buttonInsertMachine.addActionListener(listenerMachine);
		
		buttonInsertProduct = new JButton("Inserisci Prodotto");
		ActionListener listenerProduct = new InsertProductListener();
		buttonInsertProduct.addActionListener(listenerProduct);
		
		panel.add(buttonInsertClient);
		panel.add(buttonInsertEsthetic);
		panel.add(buttonInsertMachine);
		panel.add(buttonInsertDate);
		panel.add(buttonInsertProduct);
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		
		return panel;
		
	}
	
}
