package frames;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import connector.DriverManagerConnectionPool;

public class FrameProduct extends JFrame {
	
	private static final long serialVersionUID = 1L;
	JPanel panelMain;
	JPanel panelField;
	JPanel panelButton;
	JButton buttonInsert;
	JButton buttonBack;
	JLabel labelNome;
	JTextField fieldNome;
	JLabel labelPrezzo;
	JTextField fieldPrezzo;
	JLabel labelQuantit�;
	JTextField fieldQuantit�;
	JLabel labelIva;
	JTextField fieldIva;
	JLabel labelMarca;
	JTextField fieldMarca;
	JFrame frameWelcome;
	
	public FrameProduct(JFrame frameWelcome) {
		
		panelMain = new JPanel();
		panelField = createFieldPanel();
		panelButton = createButtonPanel();

		this.frameWelcome = frameWelcome; 
		
		panelMain.setLayout(new GridLayout(2, 1));
		panelMain.add(panelField);
		panelMain.add(panelButton);
		
		add(panelMain);
		
		pack();
		setTitle("Venus Passion&Beauty: Inserisci Prodotto");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	public JPanel createFieldPanel() {
		
		JPanel panel = new JPanel();
		
		labelNome = new JLabel("Inserisci Nome");
		labelMarca = new JLabel("Inserisci Marca");
		labelPrezzo = new JLabel("Inserisci Prezzo");
		labelIva= new JLabel("Inserisci IVA");
		labelQuantit� = new JLabel("Inserisci Quantit�");
		
		labelNome.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelMarca.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelPrezzo.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelIva.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelQuantit�.setForeground(new Color(1.0F, 0.8F, 0.8F));

		fieldNome = new JTextField(2);
		fieldMarca = new JTextField(2);
		fieldPrezzo = new JTextField(2);
		fieldIva = new JTextField(2);
		fieldQuantit� = new JTextField(2);
		
		panel.setLayout(new GridLayout(2, 7));
		
		panel.add(labelNome);
		panel.add(labelMarca);
		panel.add(labelPrezzo);
		panel.add(labelIva);
		panel.add(labelQuantit�);
		panel.add(fieldNome);
		panel.add(fieldNome);
		panel.add(fieldMarca);
		panel.add(fieldPrezzo);
		panel.add(fieldIva);
		panel.add(fieldQuantit�);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		return panel;
		
	}
	
	public JPanel createButtonPanel() {
		
		class ButtonBackListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				frameWelcome.setVisible(true);
				dispose();
				
			}
			
		}
		
		class ButtonInsertPanel implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(fieldNome.getText().equals("") || fieldIva.getText().equals("") || fieldMarca.getText().equals("") ||
						fieldPrezzo.getText().equals("") || fieldQuantit�.getText().equals("")) {
					
					JOptionPane.showMessageDialog(panelMain, "Riempire tutti i campi.", "Errore", JOptionPane.ERROR_MESSAGE);
					return;
					
				}
				else {
					
					Connection con = null;
					PreparedStatement ps = null;

					String sql = "INSERT INTO Prodotto (Nome, Quantit�, Prezzo, IVA, Marca) VALUES ('" + fieldNome.getText() + "' , '" + fieldQuantit�.getText() + "' , '" + fieldPrezzo.getText() + "' , '" + fieldIva.getText() + "' , '" + fieldMarca.getText() + "');";
			
					try
					{
						con = DriverManagerConnectionPool.getConnection();
						ps = con.prepareStatement(sql);
						int rows = ps.executeUpdate(sql);
						System.out.println("Numero di righe modificate: " + rows);
						con.commit();
					} 
					catch (SQLException e)
					{
						e.printStackTrace();
					}
					finally
					{
						try
						{
							ps.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						finally
						{
							try {
								DriverManagerConnectionPool.releaseConnection(con);
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
		
					}
		
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		buttonBack = new JButton("Indietro");
		ActionListener listener = new ButtonBackListener();
		buttonBack.addActionListener(listener);
		listener = new ButtonInsertPanel();
		buttonInsert = new JButton("Inserisci");
		buttonInsert.addActionListener(listener);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		panel.add(buttonInsert);
		panel.add(buttonBack);
		
		return panel;
		
	}
	
}
