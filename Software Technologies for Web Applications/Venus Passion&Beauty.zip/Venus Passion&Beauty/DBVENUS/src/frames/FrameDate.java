package frames;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import connector.DriverManagerConnectionPool;

public class FrameDate extends JFrame {
	
	private static final long serialVersionUID = 1L;
	JPanel panelMain;
	JPanel panelField;
	JPanel panelButton;
	JButton buttonInsert;
	JButton buttonBack;
	JLabel labelDurata;
	JTextField fieldDurata;
	JLabel labelOra;
	JTextField fieldOra;
	JLabel labelGiorno;
	JTextField fieldGiorno;
	JLabel labelDescrizione;
	JTextField fieldDescrizione;
	JLabel labelPrezzo;
	JTextField fieldPrezzo;
	JLabel labelTipo;
	JRadioButton radioAppuntamentoE;
	JRadioButton radioAppuntamentoM;
	JFrame frameWelcome;
	
	public FrameDate(JFrame frameWelcome) {
		
		panelMain = new JPanel();
		panelField = createFieldPanel();
		panelButton = createButtonPanel();

		this.frameWelcome = frameWelcome; 
		
		panelMain.setLayout(new GridLayout(2, 1));
		panelMain.add(panelField);
		panelMain.add(panelButton);
		
		add(panelMain);
		
		pack();
		setTitle("Venus Passion&Beauty: Inserisci Appuntamento");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	public JPanel createFieldPanel() {
		
		JPanel panel = new JPanel();
		JPanel radioPanel = new JPanel();
		
		labelDurata = new JLabel("Inserisci Durata");
		labelOra = new JLabel("Inserisci Ora (HH-MM-SS)");
		labelGiorno = new JLabel("Inserisci Giorno (YYYY-MM-GG)");
		labelDescrizione= new JLabel("Inserisci Descrizione");
		labelPrezzo = new JLabel("Inserisci Prezzo");
		labelTipo = new JLabel("                   Tipo");
		
		labelDurata.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelOra.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelGiorno.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelDescrizione.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelPrezzo.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelTipo.setForeground(new Color(1.0F, 0.8F, 0.8F));

		fieldDurata = new JTextField(2);
		fieldOra = new JTextField(2);
		fieldGiorno = new JTextField(2);
		fieldDescrizione = new JTextField(2);
		fieldPrezzo = new JTextField(2);
		
		radioAppuntamentoE = new JRadioButton("Estetista");
		radioAppuntamentoM = new JRadioButton("Macchinario");
		
		radioAppuntamentoE.setForeground(new Color(1.0F, 0.8F, 0.8F));
		radioAppuntamentoM.setForeground(new Color(1.0F, 0.8F, 0.8F));
		
		radioAppuntamentoE.setOpaque(false);
		radioAppuntamentoM.setOpaque(false);
		
		ButtonGroup group = new ButtonGroup();
		group.add(radioAppuntamentoE);
		group.add(radioAppuntamentoM);
		
		radioAppuntamentoE.setSelected(true);
		
		radioPanel.setLayout(new GridLayout(1, 2));
		radioPanel.add(radioAppuntamentoE);
		radioPanel.add(radioAppuntamentoM);
		radioPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		panel.setLayout(new GridLayout(2, 8));
		
		panel.add(labelDurata);
		panel.add(labelOra);
		panel.add(labelGiorno);
		panel.add(labelDescrizione);
		panel.add(labelPrezzo);
		panel.add(labelTipo);
		panel.add(fieldDurata);
		panel.add(fieldOra);
		panel.add(fieldGiorno);
		panel.add(fieldDescrizione);
		panel.add(fieldPrezzo);
		panel.add(radioPanel);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		return panel;
		
	}
	
	public JPanel createButtonPanel() {
		
		class ButtonBackListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				frameWelcome.setVisible(true);
				dispose();
				
			}
			
		}
		
		class ButtonInsertPanel implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(fieldDescrizione.getText().equals("") || fieldDurata.getText().equals("") || fieldGiorno.getText().equals("") ||
						fieldOra.getText().equals("")) {
					
					JOptionPane.showMessageDialog(panelMain, "Riempire tutti i campi.", "Errore", JOptionPane.ERROR_MESSAGE);
					return;
					
				}
				else {
					
					Connection con = null;
					PreparedStatement ps = null;

					try
					{
						con = DriverManagerConnectionPool.getConnection();
						
						PreparedStatement psE = con.prepareStatement("SELECT Codice_Fiscale FROM Estetista");
						ResultSet rsE = psE.executeQuery();
						
						String estetistaCF = "";
						
						while(rsE.next()) {
							estetistaCF = rsE.getString("Codice_Fiscale");
						}
						
						try
						{
							psE.close();
							rsE.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
						PreparedStatement psM = con.prepareStatement("SELECT Nome, Marca, Modello FROM Macchinario");
						ResultSet rsM = psM.executeQuery();
						
						String macchinarioNome = "";
						String macchinarioMarca = "";
						String macchinarioModello = "";
						
						while(rsM.next()) {
							macchinarioNome = rsM.getString("Nome");
							macchinarioMarca = rsM.getString("Marca");
							macchinarioModello = rsM.getString("Modello");
						}
						
						try
						{
							psM.close();
							rsM.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
						PreparedStatement psC = con.prepareStatement("SELECT Codice_Fiscale FROM Cliente");
						ResultSet rsC = psC.executeQuery();
						
						String clienteCF = "";
						
						while(rsC.next()) {
							clienteCF = rsC.getString("Codice_Fiscale");
						}
						
						try
						{
							psC.close();
							rsC.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
						String sql;
						
						if(radioAppuntamentoE.isSelected()) {
							
							sql = "INSERT INTO Appuntamento (Durata, Ora, Giorno, Descrizione, Tipo, Prezzo, Codice_Fiscale_Estetista, Codice_Fiscale_Cliente) VALUES ('" + fieldDurata.getText() + "' , '" + fieldOra.getText() + "' , '" + fieldGiorno.getText() + "' , '" + fieldDescrizione.getText() + "' , 'ESTETISTA' , '" + fieldPrezzo.getText() + "' , '" + estetistaCF + "' , '" + clienteCF + "');";
							
						}
						else {
							
							sql = "INSERT INTO Appuntamento (Durata, Ora, Giorno, Descrizione, Tipo, Prezzo, Macchinario_Marca, Macchinario_Modello, Macchinario_Nome , Codice_Fiscale_Cliente) VALUES ('" + fieldDurata.getText() + "' , '" + fieldOra.getText() + "' , '" + fieldGiorno.getText() + "' , '" + fieldDescrizione.getText() + "' , 'MACCHINARIO' , '" + fieldPrezzo.getText() + "' , '" + macchinarioMarca + "' , '" + macchinarioModello + "' , '" + macchinarioNome + "' , '" + clienteCF + "');";
							
						}
				
						
						ps = con.prepareStatement(sql);
						int rows = ps.executeUpdate(sql);
						System.out.println("Numero di righe modificate: " + rows);
						con.commit();
					} 
					catch (SQLException e)
					{
						e.printStackTrace();
					}
					finally
					{
						try
						{
							ps.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						finally
						{
							try {
								DriverManagerConnectionPool.releaseConnection(con);
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
		
					}
		
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		buttonBack = new JButton("Indietro");
		ActionListener listener = new ButtonBackListener();
		buttonBack.addActionListener(listener);
		listener = new ButtonInsertPanel();
		buttonInsert = new JButton("Inserisci");
		buttonInsert.addActionListener(listener);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		panel.add(buttonInsert);
		panel.add(buttonBack);
		
		return panel;
		
	}
	
}
