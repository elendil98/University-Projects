package frames;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import connector.DriverManagerConnectionPool;

public class FrameClient extends JFrame {
	
	private static final long serialVersionUID = 1L;
	JPanel panelMain;
	JPanel panelField;
	JPanel panelButton;
	JButton buttonInsert;
	JButton buttonBack;
	JLabel labelNome;
	JTextField fieldNome;
	JLabel labelCognome;
	JTextField fieldCognome;
	JLabel labelAnni;
	JTextField fieldAnni;
	JLabel labelCF;
	JTextField fieldCF;
	JLabel labelSesso;
	JRadioButton radioSessoM;
	JRadioButton radioSessoF;
	JFrame frameWelcome;
	
	public FrameClient(JFrame frameWelcome) {
		
		panelMain = new JPanel();
		panelField = createFieldPanel();
		panelButton = createButtonPanel();

		this.frameWelcome = frameWelcome; 
		
		panelMain.setLayout(new GridLayout(2, 1));
		panelMain.add(panelField);
		panelMain.add(panelButton);
		
		add(panelMain);
		
		pack();
		setTitle("Venus Passion&Beauty: Inserisci Cliente");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	public JPanel createFieldPanel() {
		
		JPanel panel = new JPanel();
		JPanel radioPanel = new JPanel();
		
		labelNome = new JLabel("Inserisci Nome");
		labelCognome = new JLabel("Inserisci Cognome");
		labelAnni = new JLabel("Inserisci Anni");
		labelCF = new JLabel("Inserisci CF (Max 16 caratteri)");
		labelSesso = new JLabel("                   Sesso");
		
		labelNome.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelCognome.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelAnni.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelCF.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelSesso.setForeground(new Color(1.0F, 0.8F, 0.8F));
		
		fieldNome = new JTextField(2);
		fieldCognome = new JTextField(2);
		fieldAnni = new JTextField(2);
		fieldCF = new JTextField(2);
		
		radioSessoM = new JRadioButton("Maschio");
		radioSessoF = new JRadioButton("Femmina");
		
		radioSessoM.setForeground(new Color(1.0F, 0.8F, 0.8F));
		radioSessoF.setForeground(new Color(1.0F, 0.8F, 0.8F));
		
		radioSessoM.setOpaque(false);
		radioSessoF.setOpaque(false);
		
		ButtonGroup group = new ButtonGroup();
		group.add(radioSessoM);
		group.add(radioSessoF);
		
		radioSessoM.setSelected(true);
		
		radioPanel.setLayout(new GridLayout(1, 2));
		radioPanel.add(radioSessoM);
		radioPanel.add(radioSessoF);
		radioPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		panel.setLayout(new GridLayout(2, 5));
		
		panel.add(labelNome);
		panel.add(labelCognome);
		panel.add(labelAnni);
		panel.add(labelCF);
		panel.add(labelSesso);
		panel.add(fieldNome);
		panel.add(fieldCognome);
		panel.add(fieldAnni);
		panel.add(fieldCF);
		panel.add(radioPanel);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		return panel;
		
	}
	
	public JPanel createButtonPanel() {
		
		class ButtonBackListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				frameWelcome.setVisible(true);
				dispose();
				
			}
			
		}
		
		class ButtonInsertPanel implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(fieldNome.getText().equals("") || fieldCognome.getText().equals("") || 
						fieldAnni.getText().equals("") || fieldCF.getText().equals("")) {
					
					JOptionPane.showMessageDialog(panelMain, "Riempire tutti i campi.", "Errore", JOptionPane.ERROR_MESSAGE);
					return;
					
				}
				else {
					
					Connection con = null;
					PreparedStatement ps = null;

					String sql;
					
					if(radioSessoM.isSelected()) {
						
						sql = "INSERT INTO Cliente (Nome, Cognome, Sesso, Anni, Codice_Fiscale) VALUES ('" + fieldNome.getText() + "' , '" + fieldCognome.getText() + "', 'M', '" + fieldAnni.getText() + "' , '" + fieldCF.getText() + "')";
						
					}
					else {
						
						sql = "INSERT INTO Cliente (Nome, Cognome, Sesso, Anni, Codice_Fiscale) VALUES ('" + fieldNome.getText() + "' , '" + fieldCognome.getText() + "', 'F', '" + fieldAnni.getText() + "' , '" + fieldCF.getText() + "')";
						
					}
			
					try
					{
						con = DriverManagerConnectionPool.getConnection();
						ps = con.prepareStatement(sql);
						int rows = ps.executeUpdate(sql);
						System.out.println("Numero di righe modificate: " + rows);
						con.commit();
					} 
					catch (SQLException e)
					{
						e.printStackTrace();
					}
					finally
					{
						try
						{
							ps.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						finally
						{
							try {
								DriverManagerConnectionPool.releaseConnection(con);
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
		
					}
		
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		buttonBack = new JButton("Indietro");
		ActionListener listener = new ButtonBackListener();
		buttonBack.addActionListener(listener);
		listener = new ButtonInsertPanel();
		buttonInsert = new JButton("Inserisci");
		buttonInsert.addActionListener(listener);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		panel.add(buttonInsert);
		panel.add(buttonBack);
		
		return panel;
		
	}
	
}
