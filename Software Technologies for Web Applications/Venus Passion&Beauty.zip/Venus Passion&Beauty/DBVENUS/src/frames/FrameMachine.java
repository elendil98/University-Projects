package frames;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import connector.DriverManagerConnectionPool;

public class FrameMachine extends JFrame {
	
	private static final long serialVersionUID = 1L;
	JPanel panelMain;
	JPanel panelField;
	JPanel panelButton;
	JButton buttonInsert;
	JButton buttonBack;
	JLabel labelNome;
	JTextField fieldNome;
	JLabel labelMarca;
	JTextField fieldMarca;
	JLabel labelModello;
	JTextField fieldModello;
	JLabel labelDescrizione;
	JTextField fieldDescrizione;
	JLabel labelTipo;
	JRadioButton radioLampada;
	JRadioButton radioFotoepilazione;
	JFrame frameWelcome;
	
	public FrameMachine(JFrame frameWelcome) {
		
		panelMain = new JPanel();
		panelField = createFieldPanel();
		panelButton = createButtonPanel();

		this.frameWelcome = frameWelcome; 
		
		panelMain.setLayout(new GridLayout(2, 1));
		panelMain.add(panelField);
		panelMain.add(panelButton);
		
		add(panelMain);
		
		pack();
		setTitle("Venus Passion&Beauty: Inserisci Macchinario");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}
	
	public JPanel createFieldPanel() {
		
		JPanel panel = new JPanel();
		JPanel radioPanel = new JPanel();
		
		labelNome = new JLabel("Inserisci Nome");
		labelModello = new JLabel("Inserisci Modello");
		labelMarca = new JLabel("Inserisci Marca");
		labelDescrizione= new JLabel("Inserisci Descrizione");
		labelTipo = new JLabel("                   Tipo");
		
		labelNome.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelModello.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelMarca.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelDescrizione.setForeground(new Color(1.0F, 0.8F, 0.8F));
		labelTipo.setForeground(new Color(1.0F, 0.8F, 0.8F));
		
		fieldNome = new JTextField(2);
		fieldModello = new JTextField(2);
		fieldMarca = new JTextField(2);
		fieldDescrizione = new JTextField(2);
		
		radioLampada = new JRadioButton("Lampada");
		radioFotoepilazione = new JRadioButton("Fotoepilazione");
		
		radioLampada.setForeground(new Color(1.0F, 0.8F, 0.8F));
		radioFotoepilazione.setForeground(new Color(1.0F, 0.8F, 0.8F));
		
		radioFotoepilazione.setOpaque(false);
		radioLampada.setOpaque(false);
		
		ButtonGroup group = new ButtonGroup();
		group.add(radioLampada);
		group.add(radioFotoepilazione);
		
		radioLampada.setSelected(true);
		
		radioPanel.setLayout(new GridLayout(1, 2));
		radioPanel.add(radioLampada);
		radioPanel.add(radioFotoepilazione);
		radioPanel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		panel.setLayout(new GridLayout(2, 5));
		
		panel.add(labelNome);
		panel.add(labelMarca);
		panel.add(labelModello);
		panel.add(labelDescrizione);
		panel.add(labelTipo);
		panel.add(fieldNome);
		panel.add(fieldNome);
		panel.add(fieldMarca);
		panel.add(fieldModello);
		panel.add(fieldDescrizione);
		panel.add(radioPanel);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		return panel;
		
	}
	
	public JPanel createButtonPanel() {
		
		class ButtonBackListener implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				frameWelcome.setVisible(true);
				dispose();
				
			}
			
		}
		
		class ButtonInsertPanel implements ActionListener {
			
			public void actionPerformed(ActionEvent event) {
				
				if(fieldNome.getText().equals("") || fieldDescrizione.getText().equals("") || fieldMarca.getText().equals("") ||
						fieldModello.getText().equals("")) {
					
					JOptionPane.showMessageDialog(panelMain, "Riempire tutti i campi.", "Errore", JOptionPane.ERROR_MESSAGE);
					return;
					
				}
				else {
					
					Connection con = null;
					PreparedStatement ps = null;

					String sql;
					
					if(radioLampada.isSelected()) {
						
						sql = "INSERT INTO Macchinario (Marca, Modello, Nome, Descrizione, Tipo) VALUES ('" + fieldMarca.getText() + "' , '" + fieldModello.getText() + "' , '" + fieldNome.getText() + "' , '" + fieldDescrizione.getText() + "' , 'LAMPADA');";
						
					}
					else {
						
						sql = "INSERT INTO Macchinario (Marca, Modello, Nome, Descrizione, Tipo) VALUES ('" + fieldMarca.getText() + "' , '" + fieldModello.getText() + "' , '" + fieldNome.getText() + "' , '" + fieldDescrizione.getText() + "' , 'FOTOEPILAZIONE');";
						
					}
			
					try
					{
						con = DriverManagerConnectionPool.getConnection();
						ps = con.prepareStatement(sql);
						int rows = ps.executeUpdate(sql);
						System.out.println("Numero di righe modificate: " + rows);
						con.commit();
					} 
					catch (SQLException e)
					{
						e.printStackTrace();
					}
					finally
					{
						try
						{
							ps.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						finally
						{
							try {
								DriverManagerConnectionPool.releaseConnection(con);
							} catch (SQLException e) {
								e.printStackTrace();
							}
							
						}
		
					}
		
				}
				
			}
			
		}
		
		JPanel panel = new JPanel();
		
		buttonBack = new JButton("Indietro");
		ActionListener listener = new ButtonBackListener();
		buttonBack.addActionListener(listener);
		listener = new ButtonInsertPanel();
		buttonInsert = new JButton("Inserisci");
		buttonInsert.addActionListener(listener);
		
		panel.setBackground(new Color(0.3F, 0.3F, 0.3F));
		
		panel.add(buttonInsert);
		panel.add(buttonBack);
		
		return panel;
		
	}
	
}
