package testing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import connector.DriverManagerConnectionPool;

public class OperationTester
{

	public OperationTester() {}

	public void menu()
	{

		System.out.println("Benveuto!");


		int scelta = -1;
		Scanner in = new Scanner(System.in);

		System.out.println("Quale operazione vuoi eseguire?");
		while(scelta != 0)
		{

			System.out.println("Op. 1: Aggiungi un negozio");
			System.out.println("Op. 2: Visualizza i dati degli impiegati"); 
			System.out.println("Op. 3: Acquista due prodotti con tessera");
			System.out.println("Op. 4: Visualizza tutti gli ordini effettuati da un supervisore");
			System.out.println("Op. 5: Visualizza tutti i clienti che hanno comprato un Computer");
			System.out.println("Op. 6: Visualizza il nome e il cognome dei magazzinieri e dei commessi del primo negozio");
			System.out.println("Op. 7: Visualizza il numero di dipendenti");
			System.out.println("Op. 8: Aggiorna i valori dello stipendio dei supervisori (x1,5)");

			System.out.print("Scelta: ");
			scelta = in.nextInt();
			switch(scelta)
			{
			case 1:
				aggiungiNegozio();
				scelta = -1;
				break;
			case 2:
				visualizzaImpiegati();
				scelta = -1;
				break;
			case 3:
				acquistoTessera();
				scelta = -1;
				break;
			case 4:
				visualizzaOrdineSupervisore();
				scelta = -1;
				break;
			case 5:
				visualizzaClientiComputer();
				scelta = -1;
				break;
			case 6:
				visualizzaCommMagazPrimoNegozio();
				scelta = -1;
				break;
			case 7:
				contaNumeroDipendenti();
				scelta = -1;
				break;
			case 8:
				aggiornaStipendiSupervisori();
				scelta = -1;
			case 0:
				break;
			default:
				System.out.println("Nessun operazione selezionata!");
				break;
			}


		}

		in.close();
	}

	// OP1
	private void aggiungiNegozio()
	{
		Connection con = null;
		PreparedStatement ps = null;

		String sql = "INSERT INTO Negozio (nome, indirizzo) values ('MediaWorld Salerno', 'Via Trento 45')";

		try
		{
			con = DriverManagerConnectionPool.getConnection();
			ps = con.prepareStatement(sql);
			int rows = ps.executeUpdate(sql);
			System.out.println("Numero di righe modificate: " + rows);
			con.commit();
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally
			{
				try {
					DriverManagerConnectionPool.releaseConnection(con);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// OP2
	private void visualizzaImpiegati()
	{
		Connection con = null;
		PreparedStatement ps = null;

		try
		{
			con = DriverManagerConnectionPool.getConnection();
			ps = con.prepareStatement("SELECT * FROM Impiegato");
			ResultSet rs = ps.executeQuery();
			System.out.println("Codice | Nome | Congnome | Stipendio | ID Negozio");
			while(rs.next())
			{
				System.out.println(rs.getInt("Codice") + " | " +
						rs.getString("Nome") + " | " + rs.getString("Cognome") + " | " +
						rs.getFloat("Stipendio") + " | " + rs.getInt("ID_Negozio"));
			}
			System.out.println("\n");
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();;
			}
			finally
			{
				try {
					DriverManagerConnectionPool.releaseConnection(con);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// OP3
	private void acquistoTessera()
	{
		Connection con = null;
		PreparedStatement ps = null;
		
		String[] sqls = new String[4];
		sqls[0] = "insert into Ricevuta (metodo_di_pagamento, fattura, codice_commesso, codice_cliente, codice_tessera)" + 
				"values ('Banconote', 0, 8, 'CRTLYL04P48L736D', 1)";
		sqls[1] = "insert into Si_Compone_Di (codice_ricevuta, codice_prodotto) values (4, 5)";
		sqls[2] = "update prodotto set quantit� = quantit� -1 where codice = 5";
		sqls[3] = "update tessera set punti = punti + 10 where codice_cliente = 'CRTLYL04P48L736D'";

		try
		{
			con = DriverManagerConnectionPool.getConnection();
			int i = 0;
			int rows = 0;
			for(String s: sqls)
			{
				ps = con.prepareStatement(s);
				if((rows = ps.executeUpdate()) > 0)
					System.out.println("Operazione: " + i++ + "avvenuta con successo!\n" + 
				"Righe Modificate: " + rows + "\n");
			}
			con.commit();
		} 
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					DriverManagerConnectionPool.releaseConnection(con);
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}

	// OP4
	private void visualizzaOrdineSupervisore()
	{

		Connection con = null;
		PreparedStatement ps = null;

		try
		{
			con = DriverManagerConnectionPool.getConnection();
			ps = con.prepareStatement("SELECT DISTINCT * FROM ordine WHERE ordine.codice_supervisore = 1");
			ResultSet rs = ps.executeQuery();

			System.out.println("Codice | Saldo ordine | Data ordine | Codice Supervisore");
			while(rs.next())
			{
				System.out.println(rs.getInt("Codice") + 
						" | " + rs.getFloat("Saldo_Ordine") + " | " + rs.getDate("Data_Ordine") + 
						" | " + rs.getInt("Codice_Supervisore"));
			}
			System.out.println("\n");
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				ps.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try {
					DriverManagerConnectionPool.releaseConnection(con);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	// OP5
	private void visualizzaClientiComputer()
	{
		Connection con = null;
		PreparedStatement ps = null;

		try
		{
			con = DriverManagerConnectionPool.getConnection();
			ps = con.prepareStatement("select c.*\r\n" + 
					"from cliente as c inner join (select r.codice_cliente\r\n" + 
					"	from ricevuta as r inner join (select comp.codice_ricevuta\r\n" + 
					"		from si_compone_di as comp inner join (select d.codice_prodotto, r.nome_reparto\r\n" + 
					"			from disponibile as d inner join reparto as r\r\n" + 
					"			on d.codice_reparto = r.codice and r.nome_reparto = 'Computer') as PDisp\r\n" + 
					"		on comp.codice_prodotto = PDisp.codice_prodotto) as RiComp\r\n" + 
					"	on r.codice = RiComp.codice_ricevuta) CRic\r\n" + 
					"on c.codice_fiscale = CRic.codice_cliente");
			ResultSet rs = ps.executeQuery();
			System.out.println("Codice Fiscale | Nome | Cognome | Tessera");
			while(rs.next())
			{
				System.out.println(rs.getString("Codice_Fiscale") + " | " + rs.getString("Nome") + 
						" | " + rs.getString("Cognome") + " | " + rs.getBoolean("Tessera"));
			}
			System.out.println("\n");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try {
					DriverManagerConnectionPool.releaseConnection(con);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}


	// OP6
	private void visualizzaCommMagazPrimoNegozio()
	{
		Connection con = null;
		PreparedStatement ps = null;

		try
		{
			con = DriverManagerConnectionPool.getConnection();
			ps = con.prepareStatement("select i1.nome, i1.cognome\r\n" + 
					"from impiegato as i1, commesso as c\r\n" + 
					"where i1.codice = c.codice_impiegato and i1.id_negozio = 1\r\n" + 
					"union\r\n" + 
					"select i2.nome, i2.cognome\r\n" + 
					"from impiegato as i2, magazziniere as m\r\n" + 
					"where i2.codice = m.codice_impiegato and i2.id_negozio = 1");
			ResultSet rs = ps.executeQuery();
			System.out.println("Nome | Cognome");
			while(rs.next())
			{
				System.out.println(rs.getString("Nome") + " | "+  rs.getString("Cognome"));
			}
			System.out.println("\n");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					DriverManagerConnectionPool.releaseConnection(con);
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	// OP7
	private void contaNumeroDipendenti()
	{
		Connection con = null;
		PreparedStatement ps = null;
		
		 try
		 {
			 con = DriverManagerConnectionPool.getConnection();
			 ps = con.prepareStatement("SELECT COUNT(*) FROM Impiegato");
			 ResultSet rs = ps.executeQuery();
			 while(rs.next())
			 {
				 System.out.println("Numero di dipendenti: " + rs.getInt("COUNT(*)"));
			 }
			 System.out.println("\n");
		 }
		 catch(SQLException e)
		 {
			 e.printStackTrace();
		 }
		 finally
		 {
			 try
			 {
				 ps.close();
			 }
			 catch(SQLException e)
			 {
				 e.printStackTrace();
			 }
			 finally
			 {
				 try
				 {
					 DriverManagerConnectionPool.releaseConnection(con);
				 }
				 catch(SQLException e)
				 {
					 e.printStackTrace();
				 }
			 }
		 }
	}
	
	// OP8
	private void aggiornaStipendiSupervisori()
	{
		Connection con = null;
		PreparedStatement ps = null;
		
		try
		{
			con = DriverManagerConnectionPool.getConnection();
			ps = con.prepareStatement("update Impiegato i\r\n" + 
					"inner join Supervisore s\r\n" + 
					"on i.codice = s.codice_impiegato\r\n" + 
					"set stipendio = stipendio * 1.5;");
			int rows = ps.executeUpdate();
			if(rows > 0)
			{
				System.out.println("Righe modificate: " + rows);
			}
			else
			{
				System.out.println("Non � stata modificata nessuna riga!");
			}
			con.commit();
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					DriverManagerConnectionPool.releaseConnection(con);
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}

	// Starter
	public static void main(String[] args)
	{
		OperationTester op = new OperationTester();
		op.menu();
	}
}
