USE venus_passion_beauty;

/* Popolamento Utenti */
/*
INSERT INTO Utente(Username, Pass, Email, Nome, Cognome, Ruolo) VALUES ('username1', 'pass1', 'email1', 'nome1', 'cognome1', 'admin');
INSERT INTO Utente(Username, Pass, Email, Nome, Cognome, Ruolo) VALUES ('username2', 'pass2', 'email2', 'nome2', 'cognome2', 'utente');
INSERT INTO Utente(Username, Pass, Email, Nome, Cognome, Ruolo) VALUES ('username3', 'pass3', 'email3', 'nome3', 'cognome3', 'utente');
INSERT INTO Utente(Username, Pass, Email, Nome, Cognome, Ruolo) VALUES ('username4', 'pass4', 'email4', 'nome4', 'cognome4', 'utente');
INSERT INTO Utente(Username, Pass, Email, Nome, Cognome, Ruolo) VALUES ('username5', 'pass5', 'email5', 'nome5', 'cognome5', 'utente');
*/

/* Popolamento Prodotti */
/*
INSERT INTO Carrello (Codice_Prodotto, Email_Acquirente) VALUES ('A1' , 'email1');
*/

