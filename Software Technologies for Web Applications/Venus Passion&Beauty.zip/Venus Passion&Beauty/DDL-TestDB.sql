DROP DATABASE IF EXISTS venus_passion_beauty;
CREATE DATABASE venus_passion_beauty;
USE venus_passion_beauty;

/* TABLE: Utente */
DROP TABLE IF EXISTS Utente;
CREATE TABLE Utente (
	Username VARCHAR(50) NOT NULL,
    Pass VARCHAR(30) NOT NULL,
    Email VARCHAR(50) NOT NULL UNIQUE,
	Nome VARCHAR(30) NOT NULL,
    Cognome VARCHAR(30) NOT NULL,
    Ruolo VARCHAR(20),
    PRIMARY KEY(Username)
) ENGINE INNODB;

/* TABLE: Prodotto */
DROP TABLE IF EXISTS Prodotto;
CREATE TABLE Prodotto (
	Codice VARCHAR(20) NOT NULL,
    Nome VARCHAR(30) NOT NULL,
    Prezzo DOUBLE NOT NULL,
    Marca VARCHAR(30) NOT NULL,
    Immagine MEDIUMBLOB,
    PRIMARY KEY(Codice)
) ENGINE INNODB;

DROP TABLE IF EXISTS Carrello;
CREATE TABLE Carrello (
	Codice_Prodotto VARCHAR(20)  NOT NULL,
    Email_Acquirente VARCHAR(50) NOT NULL,
    FOREIGN KEY(Codice_Prodotto) REFERENCES Prodotto(Codice),
    FOREIGN KEY(Email_Acquirente) REFERENCES Utente(Email)
) ENGINE INNODB;
