USE venus_passion_beauty;

/* Selezione Totale */

SELECT * FROM Utente;
SELECT * FROM Prodotto;
SELECT * FROM Carrello;

/*
INSERT INTO Utente (Username, Pass, Email, Nome, Cognome, Ruolo) vALUES ('admin', 'admin', 'studente@admin.it', 'AdminName', 'AdminSurname', 'admin');
*/